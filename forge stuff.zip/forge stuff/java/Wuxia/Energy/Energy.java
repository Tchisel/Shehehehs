package Wuxia.Energy;

import java.util.Random;

import Wuxia.Energy.stun.IStun;
import Wuxia.Energy.stun.StundProvider;
import Wuxia.network.MessageEnergy;
import Wuxia.util.handlers.NetworkHandler;
import Wuxia.util.interfaces.IEnergy;
import Wuxia.util.interfaces.Stages;
import Wuxia.util.interfaces.Stat;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.common.util.Constants.AttributeModifierOperation;

// TODO: Auto-generated Javadoc
/**
 * The Class Energy.
 */
public class Energy implements IEnergy {

	/** The energy. */
	private int energy = 20;

	/** The max energy. */
	private int maxEnergy = 20;

	/** Is the Player alive. */
	private int alive = 1;

	/** The latent talent. */
	private int latentTalent = 0;

	/** The luck. */
	private int luck = 0;
	private int[] stats = { 1, 1, 1, 1, 1 };
	/** The gc. */
	private boolean gc = true;

	private int lastIncrease = 0;

	private EntityPlayer player;

	private Stages stage = Stages.MORTAL;

	private Stat STRENGTH = Stat.STRENTGH;
	private Stat SPEED = Stat.SPEED;
	private Stat DIVINESENSE = Stat.DIVINESENSE;
	private Stat SPIRIT = Stat.SPIRIT;
	private Stat VITALITY = Stat.VITALITY;

	/**
	 * Sets the max energy.
	 *
	 * @param amount the new max energy
	 */
	@Override
	public void setMaxEnergy(int amount) {
		this.maxEnergy = amount;
		if (player != null && player instanceof EntityPlayerMP) {
			sendChanges(player);
		}

	}

	/**
	 * Gets the energy.
	 *
	 * @return the energy
	 */
	@Override
	public int getEnergy() {
		return energy;
	}

	@Override
	public void getPlayer(EntityPlayer player) {
		this.player = player;
	}

	@Override
	public void sendChanges(EntityPlayer player) {
		if (player != null && player instanceof EntityPlayerMP) {
			NetworkHandler.sendEnergyMessage(
					new MessageEnergy(getEnergy(), getMaxEnergy(), player.getHealth(), player.getMaxHealth()), player);
		}
	}

	/**
	 * Increase energy.
	 *
	 * @param amount the amount
	 * @return the int
	 */
	@Override
	public int increaseEnergy(int amount, EntityPlayer player) {

		if (energy == maxEnergy) {
			int increaseEnergy = new Random().nextInt(((maxEnergy / getLatentTalent() + amount) / 10));
			if (increaseEnergy + getMaxEnergy() >= getStageLimit(getStage())) {
				int overFlow = increaseEnergy + getMaxEnergy() - getStageLimit(getStage());
				if (increaseStage(overFlow, player)) {
				} else {
					for (int i = (overFlow / 15); i > 0; i -= (maxEnergy / 10 * getLatentTalent())) {
						increaseMaxEnergy(increaseEnergy);
						energy = maxEnergy;
						IStun stun = player.getCapability(StundProvider.stunResource, null);
						if (stun.getIsStunnned()) {
							stun.setstunDuration(stun.getstunDuration() + 50 * i);
						}
						stun.setIsStunnned(true);
						stun.setstunDuration(50 * i);
					}
				}
			} else {
				for (int i = increaseEnergy; i > 0; i -= (maxEnergy / 10 * getLatentTalent())) {
					increaseMaxEnergy(increaseEnergy);
					energy = maxEnergy;
					IStun stun = player.getCapability(StundProvider.stunResource, null);
					if (stun.getIsStunnned()) {
						stun.setstunDuration(stun.getstunDuration() + 25 * i);
					}
					stun.setIsStunnned(true);
					stun.setstunDuration(25 * i);
				}
			}
		} else if ((energy + amount) > maxEnergy) {
			int increaseEnergy = new Random()
					.nextInt(((maxEnergy / getLatentTalent()) + (energy - maxEnergy + amount)) / 10);
			if (increaseEnergy + getMaxEnergy() >= getStageLimit(getStage())) {
				int overFlow = increaseEnergy + getMaxEnergy() - getStageLimit(getStage());
				if (increaseStage(overFlow, player)) {
				} else {
					for (int i = (overFlow / 15); i > 0; i -= (maxEnergy / 10 * getLatentTalent())) {
						increaseMaxEnergy(increaseEnergy);
						energy = maxEnergy;
						IStun stun = player.getCapability(StundProvider.stunResource, null);
						stun.setIsStunnned(true);
						stun.setstunDuration(50);
					}
				}
			} else {

				for (int i = increaseEnergy; i > 0; i -= (maxEnergy / 10 * getLatentTalent())) {
					increaseMaxEnergy(increaseEnergy);
					energy = maxEnergy;
					IStun stun = player.getCapability(StundProvider.stunResource, null);
					stun.setIsStunnned(true);
					stun.setstunDuration(25);
				}
			}
		} else {
			energy += amount;
		}
		if (player != null && player.isServerWorld()) {
			sendChanges(player);
		}
		return energy;
	}

	@Override
	public int getStageLimit(Stages stage2) {
		switch (stage2) {
		case JINDANIMMORTAL:
			return Integer.MAX_VALUE;
		case MORTAL:
			return 500;
		case QICONDENSATION:
			return 20000;
		case XIANTIAN:
			return 5000;
		case ZIFUDISCIPLE:
			return 1000000;
		default:
			return 1000000;

		}
	}

	/**
	 * Decrease energy.
	 *
	 * @param amount the amount
	 * @return the int
	 */
	@Override
	public int decreaseEnergy(int amount) {
		if ((getEnergy() - amount) < 0) {
			if ((getEnergy() - amount) > -5) {
				return 0;
			} else {
				int dmgMod = getLuck() - ((getEnergy() - amount) / 3);
				int roll = new Wuxia.util.Roll().saveRoll(dmgMod);
				switch (roll) {
				case 1:

					break;
				case 0:
					maxEnergy = 0;
					energy = 0;

					break;
				case -1:
					break;
				}
				alive = roll;
			}
		}
		energy -= amount;
		if (player != null && player.isServerWorld()) {
			sendChanges(player);
		}
		return energy;
	}

	/**
	 * Increase max energy.
	 *
	 * @param amount the amount
	 */
	@Override
	public void increaseMaxEnergy(int amount) {
		for (int i = getLastLevelUp(); i < getMaxEnergy() + amount; i += 25) {
			upgrader(new Random());
			setLastLevelUp(i);

		}
		maxEnergy += amount;
		if (player != null && player.isServerWorld()) {
			sendChanges(player);
		}
	}

	/**
	 * Decrease max energy.
	 *
	 * @param amount the amount
	 */
	@Override
	public void decreaseMaxEnergy(int amount) {
		if ((getMaxEnergy() - amount) < 0) {
			int dmgMod = getLuck() - ((getMaxEnergy() - amount) / 3);
			new Wuxia.util.Roll().saveRoll(dmgMod);
		}
		maxEnergy -= amount;
		if (player != null && player.isServerWorld()) {
			sendChanges(player);
		}
	}

	/**
	 * Gets the max energy.
	 *
	 * @return the max energy
	 */
	@Override
	public int getMaxEnergy() {
		return maxEnergy;
	}

	/**
	 * Gets the alive.
	 *
	 * @return the alive
	 */
	@Override
	public int getAlive() {
		return alive;
	}

	/**
	 * Sets the energy.
	 *
	 * @param amount the new energy
	 */
	@Override
	public void setEnergy(int amount) {
		this.energy = amount;
		if (player != null && player.isServerWorld()) {
			sendChanges(player);
		}

	}

	/**
	 * Sets the alive.
	 *
	 * @param alive the new alive
	 */
	@Override
	public void setAlive(int alive) {
		this.alive = alive;

	}

	/**
	 * Gets the latent talent.
	 *
	 * @return the latent talent
	 */
	@Override
	public int getLatentTalent() {
		if (latentTalent <= 0) {
			setLatentTalent((new Random().nextInt(7)) + 1);
		}
		return this.latentTalent;
	}

	/**
	 * Sets the latent talent.
	 *
	 * @param amount the new latent talent
	 */
	@Override
	public void setLatentTalent(int amount) {
		if (amount <= 0) {
			amount = (new Random().nextInt(7)) + 1;
		}
		this.latentTalent = amount;

	}

	/**
	 * Gets the luck.
	 *
	 * @return the luck
	 */
	@Override
	public int getLuck() {
		if (luck <= 0) {
			setLuck((new Random().nextInt(9)) + 1);
		}
		return this.luck;
	}

	/**
	 * Sets the luck.
	 *
	 * @param amount the new luck
	 */
	@Override
	public void setLuck(int amount) {
		if (amount <= 0) {
			setLuck((new Random().nextInt(9)) + 1);
		}
		this.luck = amount;

	}

	/**
	 * Gets the all values.
	 *
	 * @return the all values
	 */
	@Override
	public Energy getAllValues() {
		return this;
	}

	/**
	 * Sets the all values.
	 *
	 * @param energy the new all values
	 */
	@Override
	public void setAllValues(Energy energy) {
		this.alive = energy.getAlive();
		this.energy = energy.getEnergy();
		this.latentTalent = energy.getLatentTalent();
		this.luck = energy.getLuck();
		this.maxEnergy = energy.getMaxEnergy();
		this.DIVINESENSE = energy.DIVINESENSE;
		this.SPEED = energy.SPEED;
		this.STRENGTH = energy.STRENGTH;
		this.SPIRIT = energy.SPIRIT;
		this.VITALITY = energy.VITALITY;
		this.DIVINESENSE = energy.DIVINESENSE;
		this.stats = energy.stats;

	}

	/**
	 * Gets the gc.
	 *
	 * @return the gc
	 */
	@Override
	public boolean getGc() {
		// TODO Auto-generated method stub
		return this.gc;
	}

	/**
	 * Sets the gc.
	 *
	 * @param gc the new gc
	 */
	@Override
	public void setGc(boolean gc) {
		this.gc = gc;

	}

	@Override
	public Stages getStage() {
		return stage;
	}

	@Override
	public void setStage(Stages stage) {
		this.stage = stage;

	}

	@Override
	public boolean increaseStage(int energyOveflow, EntityPlayer player) {
		Random random = new Random();
		switch (stage) {
		case JINDANIMMORTAL:
			break;
		case MORTAL:
			if ((energyOveflow - 500) > ((random.nextInt(500) - (getLuck() * energyOveflow / (random.nextInt(8) + 1)))
					/ getLatentTalent())) {
				stage = Stages.XIANTIAN;
				for (int i = 0; i < (random.nextInt(getLuck() * getLatentTalent() + 1) + 10); i++) {
					upgrader(random);
				}
				if (!player.getEntityWorld().isRemote)
					player.sendMessage(new TextComponentString("You successfully broke through"));
				return true;
			} else {
				return false;
			}
		case XIANTIAN:
			if ((energyOveflow
					- 5000) > ((random.nextInt(20000) - (getLuck() * energyOveflow / (random.nextInt(8) + 1)))
							/ getLatentTalent())) {
				stage = Stages.QICONDENSATION;
				for (int i = 0; i < (random.nextInt(getLuck() * getLatentTalent() + 1) + 10); i++) {
					upgrader(random);
				}
				if (!player.getEntityWorld().isRemote)
					player.sendMessage(new TextComponentString("You successfully broke through"));
				return true;
			} else {
				return false;
			}
		case QICONDENSATION:
			if ((energyOveflow
					- 20000) > ((random.nextInt(20000) - (getLuck() * energyOveflow / (random.nextInt(8) + 1)))
							/ getLatentTalent())) {
				stage = Stages.ZIFUDISCIPLE;
				for (int i = 0; i < (random.nextInt(getLuck() * getLatentTalent() + 1) + 10); i++) {
					upgrader(random);
				}
				if (!player.getEntityWorld().isRemote)
					player.sendMessage(new TextComponentString("You successfully broke through"));
				return true;
			} else {
				return false;
			}
		case ZIFUDISCIPLE:
			if ((energyOveflow
					- 1000000) > ((random.nextInt(1000000) - (getLuck() * energyOveflow / (random.nextInt(8) + 1)))
							/ getLatentTalent())) {
				stage = Stages.JINDANIMMORTAL;
				for (int i = 0; i < (random.nextInt(getLuck() * getLatentTalent() + 1) + 10); i++) {
					upgrader(random);
				}
				if (!player.getEntityWorld().isRemote)
					player.sendMessage(new TextComponentString("You successfully broke through"));
				return true;
			} else {
				return false;
			}
		default:
			break;

		}
		return false;

	}

	private void upgrader(Random random) {
		int increase = (random.nextInt(((getLatentTalent() / 2) + 2)));
		switch (random.nextInt(5)) {
		case 1:
			stats[STRENGTH.getStat()] += increase;
		case 2:
			stats[SPEED.getStat()] += increase;
		case 3:
			stats[VITALITY.getStat()] += increase;

		case 4:
			stats[DIVINESENSE.getStat()] += increase;
		case 5:
			stats[SPIRIT.getStat()] += increase;
		default:

		}

		if (player != null && player.isServerWorld()) {
			applyVitality(player, increase);
			sendChanges(player);
		}
	}

	@Override
	public void decreaseStage(int energyOveflow, EntityPlayer player) {
		// TODO Auto-generated method stub

	}

	@Override
	public void applyVitality(EntityPlayer player, int increase) {
		player.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH)
				.applyModifier(new AttributeModifier("MaxHealth", increase, AttributeModifierOperation.ADD));

	}

	@Override
	public int getStat(Stat stat) {
		return stats[stat.getStat()];
	}

	@Override
	public void setStat(Stat stat, int value) {
		stats[stat.getStat()] = value;

	}

	@Override
	public int getLastLevelUp() {

		return lastIncrease;
	}

	@Override
	public void setLastLevelUp(int energy) {
		lastIncrease = energy;

	}

}
