package Wuxia.Energy.stun;

public interface IStun {
	int getTickStunned();

	void setTickStunned(int ticks);

	int getstunDuration();

	void setstunDuration(int ticks);

	boolean getIsStunnned();

	void setIsStunnned(boolean stun);

}
