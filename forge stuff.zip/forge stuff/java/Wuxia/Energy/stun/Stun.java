package Wuxia.Energy.stun;

public class Stun implements IStun {
	int TickStunned = 0;
	int stunDuration = 0;
	boolean isStunned = false;

	@Override
	public int getTickStunned() {
		// TODO Auto-generated method stub
		return TickStunned;
	}

	@Override
	public void setTickStunned(int ticks) {
		// TODO Auto-generated method stub
		TickStunned = ticks;
	}

	@Override
	public int getstunDuration() {
		// TODO Auto-generated method stub
		return stunDuration;
	}

	@Override
	public void setstunDuration(int ticks) {
		stunDuration = ticks;
	}

	@Override
	public boolean getIsStunnned() {
		// TODO Auto-generated method stub
		return isStunned;
	}

	@Override
	public void setIsStunnned(boolean stun) {
		isStunned = stun;

	}

}
