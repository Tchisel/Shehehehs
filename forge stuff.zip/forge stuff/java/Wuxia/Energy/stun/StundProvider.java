package Wuxia.Energy.stun;

import net.minecraft.nbt.NBTBase;
import net.minecraft.util.EnumFacing;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityInject;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;

public class StundProvider implements ICapabilitySerializable<NBTBase> {

	/** The Constant energyResource. */
	@CapabilityInject(IStun.class)
	public static final Capability<IStun> stunResource = null;

	/** The instance. */
	private IStun instance = stunResource.getDefaultInstance();

	/**
	 * Checks for capability.
	 *
	 * @param capability the capability
	 * @param facing     the direction the player is facing
	 * @return true, if successful
	 */
	@Override
	public boolean hasCapability(Capability<?> capability, EnumFacing facing) {
		return capability == stunResource;
	}

	/**
	 * Gets the capability.
	 *
	 * @param <T>        the generic type
	 * @param capability the capability
	 * @param facing     he direction the player is facing
	 * @return the capability
	 */
	@Override
	public <T> T getCapability(Capability<T> capability, EnumFacing facing) {
		return capability == stunResource ? stunResource.<T>cast(this.instance) : null;
	}

	/**
	 * Serialize NBT.
	 *
	 * @return the NBT base
	 */
	@Override
	public NBTBase serializeNBT() {
		try {
			return stunResource.getStorage().writeNBT(stunResource, this.instance, null);
		} catch (Exception e) {
			System.out.print(e);

		}
		return null;
	}

	/**
	 * Deserialize NBT.
	 *
	 * @param nbt the nbt
	 */
	@Override
	public void deserializeNBT(NBTBase nbt) {
		stunResource.getStorage().readNBT(stunResource, this.instance, null, nbt);
	}
}
