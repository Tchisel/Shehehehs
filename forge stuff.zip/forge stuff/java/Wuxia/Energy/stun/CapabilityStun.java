package Wuxia.Energy.stun;

import net.minecraft.nbt.NBTBase;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumFacing;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.Capability.IStorage;

public class CapabilityStun implements IStorage<IStun> {

	@Override
	public NBTBase writeNBT(Capability<IStun> capability, IStun instance, EnumFacing side) {
		NBTTagCompound nbt = new NBTTagCompound();
		nbt.setInteger("ticksStunned", instance.getTickStunned());
		nbt.setInteger("stunDuration", instance.getstunDuration());
		nbt.setBoolean("isStunned", instance.getIsStunnned());
		return nbt;
	}

	@Override
	public void readNBT(Capability<IStun> capability, IStun instance, EnumFacing side, NBTBase nbt) {
		instance.setTickStunned(((NBTTagCompound) nbt).getInteger("ticksStunned"));
		instance.setstunDuration(((NBTTagCompound) nbt).getInteger("stunDuration"));
		instance.setIsStunnned(((NBTTagCompound) nbt).getBoolean("isStunned"));

	}

}