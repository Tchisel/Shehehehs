package Wuxia.Energy.ablities;

import java.util.ArrayList;

import Wuxia.Energy.EnergyProvider;
import Wuxia.entites.EntityMagic;
import Wuxia.entites.abilities.fire.FireBall;
import Wuxia.util.interfaces.IAbility;
import Wuxia.util.interfaces.IEnergy;
import Wuxia.util.interfaces.Stages;
import Wuxia.util.interfaces.Stat;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class Abilities implements IAbility {

	private ArrayList<AbilitiesEnum> abilities = new ArrayList<AbilitiesEnum>();
	private int highestIndex = 0;
	private int currentIndex = 0;

	@Override
	public void slotUp() {
		if (getCurrentIndex() <= 0) {
			setCurrentIndex(0);
		} else if (getCurrentIndex() >= getHighestIndex()) {
			setCurrentIndex(getHighestIndex());
		} else {
			setCurrentIndex(getCurrentIndex() + 1);
		}
	}

	@Override
	public void slotDown() {
		if (getCurrentIndex() <= 0) {
			setCurrentIndex(getHighestIndex());
		} else if (getCurrentIndex() >= getHighestIndex()) {
			setCurrentIndex(0);
		} else {
			setCurrentIndex(getCurrentIndex() - 1);
		}
	}

	@Override
	public void setSlot(int slot, AbilitiesEnum ability) {
		if (slot > getHighestIndex()) {
			return;
		} else {
			if (getAbilities().contains(ability)) {
				getAbilities().remove(ability);
				getAbilities().add(slot, ability);
			} else {
				getAbilities().add(slot, ability);
			}
		}
	}

	@Override
	public boolean addAbility(AbilitiesEnum ability) {
		if (getAbilities().contains(ability)) {
			return false;
		} else {
			getAbilities().add(ability);
			setHighestIndex(getHighestIndex() + 1);
			return true;
		}
	}

	@Override
	public AbilitiesEnum getEquippedAbility() {
		// TODO Auto-generated method stub
		return getAbilities().get(getCurrentIndex());
	}

	@Override
	public boolean removeAbility(AbilitiesEnum ability) {
		if (!getAbilities().contains(ability)) {
			return false;
		} else {
			getAbilities().remove(ability);
			return true;
		}
	}

	@Override
	public boolean fireEquippedAbility(Entity caster, World world) {
		if (world.isRemote) {
			return false;
		}
		System.out.println("asfagaggfaffs");
		IEnergy energy;
		int energyUse;
		int spirit;
		int strength;
		int energyConsumption;
		if (caster.hasCapability(EnergyProvider.energyResource, null)) {
			energy = caster.getCapability(EnergyProvider.energyResource, null);
			energyUse = energy.getEnergy();
			spirit = energy.getStat(Stat.SPIRIT);
			strength = energy.getStat(Stat.STRENTGH);
		} else {
			return false;
		}
		Vec3d look = caster.getLookVec();
		switch (getAbilities().get(getCurrentIndex())) {
		case FIREBALL:
			energyConsumption = (int) (energy.getStage() == Stages.JINDANIMMORTAL ? energyUse >= 100000000 / 20
					: energy.getStageLimit(energy.getStage()) / 20);
			if (energyUse >= energyConsumption) {
				EntityMagic fireBall = new FireBall(world, 1.0D, 1.0D, 1.0D);
				fireBall.setPosition(caster.posX + look.x, caster.posY, caster.posZ);
				fireBall.shoot(caster, caster.rotationPitch, caster.rotationYaw, 0.0f, 3f, 0.0f);
				world.spawnEntity(fireBall);
				world.playSound(null, caster.getPosition(), SoundEvents.BLOCK_FIRE_EXTINGUISH, SoundCategory.PLAYERS,
						1.0F, 1.0F);
				fireBall.caster = caster;
				fireBall.strength = energy.getStat(Stat.SPIRIT);
				if (caster instanceof EntityPlayer) {
					EntityPlayer player = (EntityPlayer) caster;
					if (player.isCreative()) {

					} else {
						energy.decreaseEnergy(energyConsumption);
					}
				}
				return true;
			}
			break;
		default:
			if (getAbilities().get(getCurrentIndex()) == AbilitiesEnum.NONE) {
				removeAbility(AbilitiesEnum.NONE);
			}
			return false;

		}
		return false;
	}

	@Override
	public void setHighestIndex(int value) {
		this.highestIndex = value;

	}

	@Override
	public void setCurrentIndex(int value) {
		this.currentIndex = value;

	}

	@Override
	public int getHighestIndex() {
		// TODO Auto-generated method stub
		return this.highestIndex;
	}

	@Override
	public int getCurrentIndex() {
		// TODO Auto-generated method stub
		return this.currentIndex;
	}

	@Override
	public ArrayList<AbilitiesEnum> getAbilities() {
		return this.abilities;
	}

}
