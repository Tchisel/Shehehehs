package Wuxia.Energy.ablities;

import Wuxia.util.interfaces.IAbility;
import net.minecraft.nbt.NBTBase;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumFacing;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.Capability.IStorage;

public class CapabilityAbility implements IStorage<IAbility> {

	@Override
	public NBTBase writeNBT(Capability<IAbility> capability, IAbility instance, EnumFacing side) {
		NBTTagCompound nbt = new NBTTagCompound();
		int i = 0;
		if (instance.getAbilities().isEmpty()) {
			instance.addAbility(AbilitiesEnum.NONE);
		}
		for (AbilitiesEnum ability : instance.getAbilities()) {
			nbt.setString(Integer.toString(i), ability.toString());
			i++;
		}
		nbt.setInteger("maxIndex", instance.getHighestIndex());
		nbt.setInteger("currentIndex", instance.getCurrentIndex());
		nbt.setInteger("abilites", i);
		return nbt;
	}

	@Override
	public void readNBT(Capability<IAbility> capability, IAbility instance, EnumFacing side, NBTBase nbt) {
		for (int i = 0; i <= ((NBTTagCompound) nbt).getInteger("abilites"); i++) {
			instance.addAbility(AbilitiesEnum.FIREBALL
					.getAbilityFromString((((NBTTagCompound) nbt).getString(Integer.toString(i)))));
		}
		instance.setCurrentIndex(((NBTTagCompound) nbt).getInteger("currentIndex"));
		instance.setHighestIndex(((NBTTagCompound) nbt).getInteger("maxIndex"));

	}

}
