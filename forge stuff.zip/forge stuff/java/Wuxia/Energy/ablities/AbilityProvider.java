package Wuxia.Energy.ablities;

import Wuxia.util.interfaces.IAbility;
import net.minecraft.nbt.NBTBase;
import net.minecraft.util.EnumFacing;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityInject;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;

// TODO: Auto-generated Javadoc
/**
 * The Class EnergyProvider.
 */
public class AbilityProvider implements ICapabilitySerializable<NBTBase> {

	/** The Constant energyResource. */
	@CapabilityInject(IAbility.class)
	public static final Capability<IAbility> abilityResource = null;

	/** The instance. */
	private IAbility instance = abilityResource.getDefaultInstance();

	/**
	 * Checks for capability.
	 *
	 * @param capability the capability
	 * @param facing     the direction the player is facing
	 * @return true, if successful
	 */
	@Override
	public boolean hasCapability(Capability<?> capability, EnumFacing facing) {
		return capability == abilityResource;
	}

	/**
	 * Gets the capability.
	 *
	 * @param <T>        the generic type
	 * @param capability the capability
	 * @param facing     he direction the player is facing
	 * @return the capability
	 */
	@Override
	public <T> T getCapability(Capability<T> capability, EnumFacing facing) {
		return capability == abilityResource ? abilityResource.<T>cast(this.instance) : null;
	}

	/**
	 * Serialize NBT.
	 *
	 * @return the NBT base
	 */
	@Override
	public NBTBase serializeNBT() {
		try {
			return abilityResource.getStorage().writeNBT(abilityResource, this.instance, null);
		} catch (Exception e) {
			System.out.print(e);

		}
		return null;
	}

	/**
	 * Deserialize NBT.
	 *
	 * @param nbt the nbt
	 */
	@Override
	public void deserializeNBT(NBTBase nbt) {
		abilityResource.getStorage().readNBT(abilityResource, this.instance, null, nbt);
	}

}
