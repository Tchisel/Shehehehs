package Wuxia.Energy.ablities;

public enum AbilitiesEnum {
	NONE("NONE"), FIREBALL("FIREBALL");

	private String Abilitystring;

	AbilitiesEnum(String string) {
		this.Abilitystring = string;

	}

	public String getAbilityString() {
		return this.Abilitystring;
	}

	public AbilitiesEnum getAbilityFromString(String enume) {
		switch (enume) {
		case "FIREBALL":
			return FIREBALL;
		default:
			return NONE;

		}
	}
}
