package Wuxia.Energy;

import Wuxia.util.interfaces.IEnergy;
import Wuxia.util.interfaces.Stages;
import Wuxia.util.interfaces.Stat;
import net.minecraft.nbt.NBTBase;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumFacing;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.Capability.IStorage;

public class CapabilityEnergy implements IStorage<IEnergy> {

	/**
	 * Write NBT.
	 *
	 * @param capability the capability
	 * @param instance   the instance
	 * @param side       the side
	 * @return the NBT base
	 */
	@Override
	public NBTBase writeNBT(Capability<IEnergy> capability, IEnergy instance, EnumFacing side) {
		NBTTagCompound nbt = new NBTTagCompound();
		nbt.setInteger("energy", instance.getEnergy());
		nbt.setInteger("maxEnergy", instance.getMaxEnergy());
		nbt.setInteger("alive", instance.getAlive());
		nbt.setInteger("latentTalent", instance.getLatentTalent());
		nbt.setInteger("luck", instance.getLuck());
		nbt.setInteger("strength", instance.getStat(Stat.STRENTGH));
		nbt.setInteger("speed", instance.getStat(Stat.SPEED));
		nbt.setInteger("vitality", instance.getStat(Stat.VITALITY));
		nbt.setInteger("spirit", instance.getStat(Stat.SPIRIT));
		nbt.setInteger("divinesense", instance.getStat(Stat.DIVINESENSE));
		nbt.setString("stage", instance.getStage().toString());
		return nbt;
	}

	/**
	 * Read NBT.
	 *
	 * @param capability the capability
	 * @param instance   the instance
	 * @param side       the side
	 * @param nbt        the nbt
	 */
	@Override
	public void readNBT(Capability<IEnergy> capability, IEnergy instance, EnumFacing side, NBTBase nbt) {
		instance.setEnergy(((NBTTagCompound) nbt).getInteger("energy"));
		instance.setMaxEnergy(((NBTTagCompound) nbt).getInteger("maxEnergy"));
		instance.setAlive(((NBTTagCompound) nbt).getInteger("alive"));
		instance.setLatentTalent(((NBTTagCompound) nbt).getInteger("latentTalent"));
		instance.setLuck(((NBTTagCompound) nbt).getInteger("luck"));
		instance.setStat(Stat.STRENTGH, ((NBTTagCompound) nbt).getInteger("strength"));
		instance.setStat(Stat.SPEED, ((NBTTagCompound) nbt).getInteger("speed"));
		instance.setStat(Stat.VITALITY, ((NBTTagCompound) nbt).getInteger("vitality"));
		instance.setStat(Stat.SPIRIT, ((NBTTagCompound) nbt).getInteger("spirit"));
		instance.setStat(Stat.DIVINESENSE, ((NBTTagCompound) nbt).getInteger("divinesense"));
		instance.setStage(Stages.valueOf(((NBTTagCompound) nbt).getString("stage")));

	}

}
