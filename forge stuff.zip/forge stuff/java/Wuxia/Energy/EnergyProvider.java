package Wuxia.Energy;

import Wuxia.util.interfaces.IEnergy;
import net.minecraft.nbt.NBTBase;
import net.minecraft.util.EnumFacing;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityInject;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;

// TODO: Auto-generated Javadoc
/**
 * The Class EnergyProvider.
 */
public class EnergyProvider implements ICapabilitySerializable<NBTBase> {

	/** The Constant energyResource. */
	@CapabilityInject(IEnergy.class)
	public static final Capability<IEnergy> energyResource = null;

	/** The instance. */
	private IEnergy instance = energyResource.getDefaultInstance();

	/**
	 * Checks for capability.
	 *
	 * @param capability the capability
	 * @param facing     the direction the player is facing
	 * @return true, if successful
	 */
	@Override
	public boolean hasCapability(Capability<?> capability, EnumFacing facing) {
		return capability == energyResource;
	}

	/**
	 * Gets the capability.
	 *
	 * @param <T>        the generic type
	 * @param capability the capability
	 * @param facing     he direction the player is facing
	 * @return the capability
	 */
	@Override
	public <T> T getCapability(Capability<T> capability, EnumFacing facing) {
		return capability == energyResource ? energyResource.<T>cast(this.instance) : null;
	}

	/**
	 * Serialize NBT.
	 *
	 * @return the NBT base
	 */
	@Override
	public NBTBase serializeNBT() {
		try {
			return energyResource.getStorage().writeNBT(energyResource, this.instance, null);
		} catch (Exception e) {
			System.out.print(e);

		}
		return null;
	}

	/**
	 * Deserialize NBT.
	 *
	 * @param nbt the nbt
	 */
	@Override
	public void deserializeNBT(NBTBase nbt) {
		energyResource.getStorage().readNBT(energyResource, this.instance, null, nbt);
	}

}
