package Wuxia;

import Wuxia.entites.RenderTestEntity;
import Wuxia.entites.TestEntity;
import Wuxia.generator.FlowerDecorator;
import Wuxia.init.WorldGen;
import Wuxia.proxy.ClientProxy;
import Wuxia.proxy.CommonProxy;
import Wuxia.tabs.TestTab;
import Wuxia.util.References;
import Wuxia.util.handlers.RegistryHandler;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Biomes;
import net.minecraftforge.fml.client.registry.IRenderFactory;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.Mod.Instance;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent.KeyInputEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

/**
 * The Class Wuxia.
 *
 * @author Tchisel Main Class that gets initialised by Forge Constants are used
 *         by Forge Localisation in src/main/resources/assets/lang
 */
@Mod(modid = References.MODID, name = References.NAME, version = References.VERSION)
public class Wuxia {

	/** The Constant testtab. */
	public static final CreativeTabs testtab = new TestTab("testtab");

	/** The instance. */
	@Instance
	public static Wuxia instance;

	/** The proxy. */
	@SidedProxy(clientSide = References.CLIENT, serverSide = References.COMMON)
	public static CommonProxy proxy;
	public static ClientProxy clientproxy;


@SideOnly(Side.CLIENT)

@SubscribeEvent(priority=EventPriority.NORMAL, receiveCanceled=true)
public static void onEvent(KeyInputEvent event)
{
    // DEBUG
    System.out.println("Key Input Event");

    // make local copy of key binding array

    KeyBinding[] keyBindings = ClientProxy.keyBindings;

   
    // check each enumerated key binding type for pressed and take appropriate action

    if (keyBindings[0].isPressed()) 

    {

        // DEBUG

        System.out.println("Key binding ="+keyBindings[0].getKeyDescription());

            

        // do stuff for this key binding here

        // remember you may need to send packet to server

    }


}


	/**
	 * Everything in the preInit will be initialised by Forge. As Forge can handle
	 * multiple mods, First, all the preInits will be initialised
	 * 
	 * @param event = Forge Event
	 */
	@EventHandler
	public void preInit(FMLPreInitializationEvent event) {
		RegistryHandler.preInitReg();
		RenderingRegistry.registerEntityRenderingHandler(TestEntity.class, new IRenderFactory<TestEntity>() {
			@Override
			public Render<? super TestEntity> createRenderFor(RenderManager manager) {
				return new RenderTestEntity(manager);
			}
		});

	}

	/**
	 * The init event is the second Forge Initialisation event
	 * RegisterWorldGenerators registers the World Generators
	 * Biomes.PLAINS.getModdedBiomeDecorator(new FlowerDecorator()); modifies the
	 * Vanilla Plains Decorator to add custom Flowers
	 * 
	 * @param event = Forge Event
	 */
	@EventHandler
	public void Init(FMLInitializationEvent event) {
		WorldGen.registerWorldGenerators();
		Biomes.PLAINS.getModdedBiomeDecorator(new FlowerDecorator());
		proxy.init();
		
		RegistryHandler.InitReg();
		

	}

	@EventHandler
	public void serverInit(FMLServerStartingEvent event) {

		RegistryHandler.serverRegistries(event);
	}

	/**
	 * The last init event.
	 *
	 * @param event = Last Forge Initialisation Event
	 */
	@EventHandler
	public void postInit(FMLPostInitializationEvent event) {
	}

}
