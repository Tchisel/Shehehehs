package Wuxia.network;

import Wuxia.Energy.EnergyProvider;
import Wuxia.util.interfaces.IEnergy;
import io.netty.buffer.ByteBuf;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.player.EntityPlayer;

public class MessageEnergy extends MessageBase<MessageEnergy> {

	int energy;
	int maxEenergy;
	float health;
	float maxHealth;

	public MessageEnergy(int energy, int maxEnergy, float health, float maxHealth) {
		this.energy = energy;
		this.maxEenergy = maxEnergy;
		this.health = health;
		this.maxHealth = maxHealth;
	}

	public MessageEnergy() {
	}

	@Override
	public void fromBytes(ByteBuf buf) {
		energy = buf.readInt();
		maxEenergy = buf.readInt();
		health = buf.readFloat();
		maxHealth = buf.readFloat();
	}

	@Override
	public void toBytes(ByteBuf buf) {
		buf.writeInt(energy);
		buf.writeInt(maxEenergy);
		buf.writeFloat(health);
		buf.writeFloat(maxHealth);
	}

	@Override
	protected void handleClientSide(MessageEnergy message, EntityPlayer player) {
		if (player != null) {
			if ((player.hasCapability(EnergyProvider.energyResource, null))) {
				IEnergy energy = player.getCapability(EnergyProvider.energyResource, null);
				energy.setEnergy(message.energy);
				energy.setMaxEnergy(message.maxEenergy);
				player.setHealth(message.health);
				if (player.getMaxHealth() == message.maxHealth) {

				} else {
					IAttributeInstance health = player.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH);
					health.setBaseValue(message.maxHealth);
				}
			}
		}
	}

	@Override
	protected void handleServerSide(MessageEnergy message, EntityPlayer player) {
	}

}
