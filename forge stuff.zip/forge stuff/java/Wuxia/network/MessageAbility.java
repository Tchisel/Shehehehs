package Wuxia.network;

import Wuxia.Energy.ablities.AbilityProvider;
import io.netty.buffer.ByteBuf;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

public class MessageAbility extends MessageBase<MessageAbility>{

	@Override
	public MessageAbility onMessage(MessageAbility message, MessageContext ctx) {
		
		return super.onMessage(message, ctx);
	}

	@Override
	public void fromBytes(ByteBuf buf) {
		
	}

	@Override
	public void toBytes(ByteBuf buf) {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void handleClientSide(MessageAbility message, EntityPlayer player) {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void handleServerSide(MessageAbility message, EntityPlayer player) {
		player.getCapability(AbilityProvider.abilityResource, null).fireEquippedAbility(player, Minecraft.getMinecraft().world);	
		   
	}


}
