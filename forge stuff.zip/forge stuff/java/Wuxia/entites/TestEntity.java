package Wuxia.entites;

import java.util.Random;

import Wuxia.init.ItemInit;
import Wuxia.storage.StorageInventory;
import Wuxia.util.handlers.LootTableHandler;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIPanic;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.ai.EntityAIWanderAvoidWater;
import net.minecraft.item.ItemStack;
import net.minecraft.util.DamageSource;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraft.world.storage.loot.LootContext;
import net.minecraft.world.storage.loot.LootTable;

// TODO: Auto-generated Javadoc
/**
 * The Class TestEntity.
 */
public class TestEntity extends EntityCreature {

	/** The death loot table. */
	private ResourceLocation deathLootTable;

	/** The death loot table seed. */
	private long deathLootTableSeed;

	/**
	 * Instantiates a new test entity.
	 *
	 * @param worldIn the world in
	 */
	public TestEntity(World worldIn) {
		super(worldIn);

	}

	/**
	 * Inits the entity AI.
	 */
	@Override
	protected void initEntityAI() {
		this.tasks.addTask(0, new EntityAISwimming(this));
		this.tasks.addTask(1, new EntityAIPanic(this, 0.6D));
		this.tasks.addTask(2, new EntityAIWanderAvoidWater(this, 0.5D));
		this.tasks.addTask(3, new EntityAIWander(this, 0.5D));

	}

	/**
	 * Creates the child.
	 *
	 * @param ageable the ageable
	 * @return the test entity
	 */
	public TestEntity createChild(EntityAgeable ageable) {
		return new TestEntity(world);
	}

	/**
	 * Apply entity attributes.
	 */
	@Override
	protected void applyEntityAttributes() {
		super.applyEntityAttributes();
		this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(20.0D);
		this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.5D);
	}

	/**
	 * Gets the eye height.
	 *
	 * @return the eye height
	 */
	@Override
	public float getEyeHeight() {

		return 1.8f;
	}

	/**
	 * Gets the loot table.
	 *
	 * @return the loot table
	 */
	@Override
	protected ResourceLocation getLootTable() {
		// TODO Auto-generated method stub
		return LootTableHandler.TestEntity;
	}

	/**
	 * Drop loot.
	 *
	 * @param wasRecentlyHit  the was recently hit
	 * @param lootingModifier the looting modifier
	 * @param source          the source
	 */
	@Override
	protected void dropLoot(boolean wasRecentlyHit, int lootingModifier, DamageSource source) {

		ResourceLocation resourcelocation = this.deathLootTable;

		if (resourcelocation == null) {
			resourcelocation = this.getLootTable();
		}

		if (resourcelocation != null) {
			LootTable loottable = this.world.getLootTableManager().getLootTableFromLocation(resourcelocation);
			this.deathLootTable = null;
			LootContext.Builder lootcontext$builder = (new LootContext.Builder((WorldServer) this.world))
					.withLootedEntity(this).withDamageSource(source);

			if (wasRecentlyHit && this.attackingPlayer != null) {
				lootcontext$builder = lootcontext$builder.withPlayer(this.attackingPlayer)
						.withLuck(this.attackingPlayer.getLuck());
			}

			for (ItemStack itemstack : loottable.generateLootForPools(
					this.deathLootTableSeed == 0L ? this.rand : new Random(this.deathLootTableSeed),
					lootcontext$builder.build())) {
				if (itemstack.isItemEqual(new ItemStack(ItemInit.SPACE_RING))) {

					LootTable loottable1 = this.world.getLootTableManager()
							.getLootTableFromLocation(LootTableHandler.TestEntityRing);
					int i = 0;
					LootContext.Builder lootcontext$builder2 = new LootContext.Builder((WorldServer) this.world);
					for (ItemStack lootitemstack : loottable1.generateLootForPools(rand,
							lootcontext$builder2.build())) {
						new StorageInventory(itemstack).setInventorySlotContents(i, lootitemstack);
						i++;
					}
					this.entityDropItem(itemstack, 0.0F);

				} else {
					this.entityDropItem(itemstack, 0.0F);
				}
			}

			this.dropEquipment(wasRecentlyHit, lootingModifier);
		} else {
			super.dropLoot(wasRecentlyHit, lootingModifier, source);
		}
	}
}
