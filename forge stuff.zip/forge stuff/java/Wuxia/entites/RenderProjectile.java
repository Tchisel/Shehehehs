package Wuxia.entites;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;

public class RenderProjectile extends Render {
	private final float scale;
	private ResourceLocation texture;
	protected ModelBase mainModel;

	public RenderProjectile(RenderManager manager, float scale) {
		super(manager);
		this.scale = scale;
	}

	public RenderProjectile(RenderManager manager, float scale, ResourceLocation textureLoc) {
		super(manager);
		this.scale = scale;
		setTexture(textureLoc);
		bindTexture(textureLoc);
	}

	public RenderProjectile(RenderManager renderManagerIn, ModelBase modelBaseIn, float shadowSizeIn,
			ResourceLocation textureLoc) {
		super(renderManagerIn);
		this.mainModel = modelBaseIn;
		this.shadowSize = shadowSizeIn;
		this.scale = shadowSizeIn;
		setTexture(textureLoc);
	}

	public RenderProjectile setTexture(ResourceLocation textureLoc) {
		texture = textureLoc;
		return this;
	}

	/**
	 * Renders the desired {@code T} type Entity.
	 */
	@Override
	public void doRender(Entity entity, double x, double y, double z, float entityYaw, float partialTicks) {
		GlStateManager.pushMatrix();
		GlStateManager.disableCull();

		try {
			this.bindEntityTexture(entity);
			float f = this.interpolateRotation(entityYaw, entityYaw, partialTicks);
			float f1 = this.interpolateRotation(entityYaw, entityYaw, partialTicks);
			float f2 = f1 - f;

			float f7 = entity.prevRotationPitch + (entity.rotationPitch - entity.prevRotationPitch) * partialTicks;
			this.renderLivingAt(x, y, z);
			float f8 = this.handleRotationFloat();
			float f4 = 1.0F;
			float f5 = 0.0F;
			float f6 = 0.0F;

			GlStateManager.enableAlpha();
			this.mainModel.setRotationAngles(f6, f5, f8, f2, f7, f4, entity);

			GlStateManager.enableColorMaterial();
			GlStateManager.enableOutlineMode(this.getTeamColor(entity));
			this.renderModel(entity, f6, f5, f8, f2, f7, f4);

			GlStateManager.disableOutlineMode();
			GlStateManager.disableColorMaterial();

			GlStateManager.disableRescaleNormal();
		} catch (Exception exception) {

		}

		GlStateManager.setActiveTexture(OpenGlHelper.lightmapTexUnit);
		GlStateManager.enableTexture2D();
		GlStateManager.setActiveTexture(OpenGlHelper.defaultTexUnit);
		GlStateManager.enableCull();
		GlStateManager.popMatrix();
		super.doRender(entity, x, y, z, entityYaw, partialTicks);

	}

	protected void renderModel(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks,
			float netHeadYaw, float headPitch, float scaleFactor) {

		// GlStateManager.enableBlendProfile(GlStateManager.Profile.TRANSPARENT_MODEL);

		this.mainModel.render(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, 0.5f);

	}

	@Override
	public void bindTexture(ResourceLocation location) {
		super.bindTexture(location);
	}

	protected float handleRotationFloat() {
		return 0.0F;
	}

	protected void renderLivingAt(double x, double y, double z) {
		GlStateManager.translate((float) x, (float) y, (float) z);
	}

	@Override
	protected ResourceLocation getEntityTexture(Entity entity) {
		return texture;
	}

	protected float interpolateRotation(float prevYawOffset, float yawOffset, float partialTicks) {
		float f;

		for (f = yawOffset - prevYawOffset; f < -180.0F; f += 360.0F) {
			;
		}

		while (f >= 180.0F) {
			f -= 360.0F;
		}

		return prevYawOffset + partialTicks * f;
	}

}