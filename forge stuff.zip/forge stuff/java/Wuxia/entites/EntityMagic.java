package Wuxia.entites;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.projectile.EntityThrowable;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.world.World;

public class EntityMagic extends EntityThrowable {

	public Entity caster;
	public int strength;

	public EntityMagic(World worldIn) {
		super(worldIn);
	}

	@Override
	protected void entityInit() {
		// TODO Auto-generated method stub

	}

	@Override
	protected void onImpact(RayTraceResult result) {
		// TODO Auto-generated method stub

	}

	public EntityMagic(World worldIn, EntityLivingBase throwerIn) {
		super(worldIn, throwerIn);
	}

	public EntityMagic(World worldIn, double x, double y, double z) {
		super(worldIn, x, y, z);

	}
}
