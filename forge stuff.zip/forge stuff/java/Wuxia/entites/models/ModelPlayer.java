package Wuxia.entites.models;

import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;

// TODO: Auto-generated Javadoc
/**
 * ModelPlayer - Either Mojang or a mod author Created using Tabula 7.1.0
 */
public class ModelPlayer extends ModelBase {

	/** The R arm front. */
	public ModelRenderer RArmFront;

	/** The R leg front. */
	public ModelRenderer RLegFront;

	/** The Head front. */
	public ModelRenderer HeadFront;

	/** The Torso front. */
	public ModelRenderer TorsoFront;

	/** The L arm front. */
	public ModelRenderer LArmFront;

	/** The L leg front. */
	public ModelRenderer LLegFront;

	/** The Torso fron. */
	public ModelRenderer TorsoFron;

	/**
	 * Instantiates a new model player.
	 */
	public ModelPlayer() {
		this.textureWidth = 64;
		this.textureHeight = 64;
		this.RArmFront = new ModelRenderer(this, 40, 16);
		this.RArmFront.setRotationPoint(-5.0F, 2.5F, 0.0F);
		this.RArmFront.addBox(-2.0F, -2.0F, -2.0F, 3, 12, 4, 0.0F);
		this.TorsoFron = new ModelRenderer(this, 16, 32);
		this.TorsoFron.setRotationPoint(0.0F, 0.0F, 0.0F);
		this.TorsoFron.addBox(-4.0F, 0.0F, -2.0F, 8, 12, 4, 0.25F);
		this.LArmFront = new ModelRenderer(this, 32, 48);
		this.LArmFront.setRotationPoint(5.0F, 2.5F, 0.0F);
		this.LArmFront.addBox(-1.0F, -2.0F, -2.0F, 3, 12, 4, 0.0F);
		this.HeadFront = new ModelRenderer(this, 0, 0);
		this.HeadFront.setRotationPoint(0.0F, 0.0F, 0.0F);
		this.HeadFront.addBox(-4.0F, -8.0F, -4.0F, 8, 8, 8, 0.0F);
		this.LLegFront = new ModelRenderer(this, 16, 48);
		this.LLegFront.setRotationPoint(1.9F, 12.0F, 0.0F);
		this.LLegFront.addBox(-2.0F, 0.0F, -2.0F, 4, 12, 4, 0.0F);
		this.RLegFront = new ModelRenderer(this, 0, 16);
		this.RLegFront.setRotationPoint(-1.9F, 12.0F, 0.0F);
		this.RLegFront.addBox(-2.0F, 0.0F, -2.0F, 4, 12, 4, 0.0F);
		this.TorsoFront = new ModelRenderer(this, 16, 16);
		this.TorsoFront.setRotationPoint(0.0F, 0.0F, 0.0F);
		this.TorsoFront.addBox(-4.0F, 0.0F, -2.0F, 8, 12, 4, 0.0F);
	}

	/**
	 * Render.
	 *
	 * @param entity the entity
	 * @param f      the f
	 * @param f1     the f 1
	 * @param f2     the f 2
	 * @param f3     the f 3
	 * @param f4     the f 4
	 * @param f5     the f 5
	 */
	@Override
	public void render(Entity entity, float f, float f1, float f2, float f3, float f4, float f5) {
		this.RArmFront.render(f5);
		this.TorsoFron.render(f5);
		this.LArmFront.render(f5);
		this.HeadFront.render(f5);
		this.LLegFront.render(f5);
		this.RLegFront.render(f5);
		this.TorsoFront.render(f5);
	}

	/**
	 * This is a helper function from Tabula to set the rotation of model parts.
	 *
	 * @param modelRenderer the model renderer
	 * @param x             the x
	 * @param y             the y
	 * @param z             the z
	 */
	public void setRotateAngle(ModelRenderer modelRenderer, float x, float y, float z) {
		modelRenderer.rotateAngleX = x;
		modelRenderer.rotateAngleY = y;
		modelRenderer.rotateAngleZ = z;
	}

	/**
	 * Sets the rotation angles.
	 *
	 * @param limbSwing       the limb swing
	 * @param limbSwingAmount the limb swing amount
	 * @param ageInTicks      the age in ticks
	 * @param netHeadYaw      the net head yaw
	 * @param headPitch       the head pitch
	 * @param scaleFactor     the scale factor
	 * @param entityIn        the entity in
	 */
	@Override
	public void setRotationAngles(float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw,
			float headPitch, float scaleFactor, Entity entityIn) {
		this.LLegFront.rotateAngleX = MathHelper.cos(limbSwing * 0.6662F) * 1.4F * limbSwingAmount;
		this.RLegFront.rotateAngleX = MathHelper.cos(limbSwing * 0.6662F + (float) Math.PI) * 1.4F * limbSwingAmount;

		this.LArmFront.rotateAngleX = MathHelper.cos(limbSwing * 0.6662F + (float) Math.PI) * 1.4F * limbSwingAmount;
		this.RArmFront.rotateAngleX = MathHelper.cos(limbSwing * 0.6662F) * 1.4F * limbSwingAmount;

		this.HeadFront.rotateAngleY = netHeadYaw * 0.017453292F;
		this.HeadFront.rotateAngleX = headPitch * 0.017453292F;

		super.setRotationAngles(limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scaleFactor, entityIn);
	}

}
