package Wuxia.entites.abilities.fire;

import Wuxia.entites.EntityMagic;
import Wuxia.entites.models.ModelFireBall;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Blocks;
import net.minecraft.util.DamageSource;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.RayTraceResult.Type;
import net.minecraft.world.World;

public class FireBall extends EntityMagic {

	public FireBall(World worldIn) {
		super(worldIn);

	}

	public FireBall(World worldIn, EntityLivingBase throwerIn) {
		super(worldIn, throwerIn);

	}

	public FireBall(World worldIn, double x, double y, double z) {
		super(worldIn, x, y, z);
		this.setSize(4f, 4f);
	}

	public void render() {
		new ModelFireBall().render(this, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f);
	}

	@Override
	protected void onImpact(RayTraceResult result) {
		if (!this.world.isRemote) {
			Entity hit = result.entityHit;
			if (hit != null) {
				if (hit instanceof EntityMagic) {
					EntityMagic hitter = (EntityMagic) hit;
					if (hitter.strength >= this.strength) {
						this.setDead();

					} else {
						this.strength -= hitter.strength;
					}
				} else if (hit != this.caster) {
					result.entityHit.attackEntityFrom(DamageSource.causeThrownDamage(this, this.caster), this.strength);
					result.entityHit.setFire(2);
					this.setDead();
				}
			}
			if (result.typeOfHit == Type.BLOCK) {
				this.world.createExplosion(this, this.posX, this.posY, this.posZ, this.strength / 30, true);
				int Xx = this.getPosition().getX();
				int Zz = this.getPosition().getZ();
				int Yy = this.getPosition().getY();
				for (int i = 0; i < this.strength / 30; i++) {
					for (int j = 0; j < this.strength / 30; j++) {
						this.world.setBlockState(new BlockPos(Xx + i, Yy, Zz + j), Blocks.FIRE.getDefaultState(), 11);
					}
				}
				this.setDead();
			}
		}
	}

}
