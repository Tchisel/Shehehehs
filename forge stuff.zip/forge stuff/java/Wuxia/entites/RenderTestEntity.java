package Wuxia.entites;

import Wuxia.entites.models.ModelPlayer;
import Wuxia.util.References;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;

// TODO: Auto-generated Javadoc
/**
 * The Class RenderTestEntity.
 */
public class RenderTestEntity extends RenderLiving<TestEntity> {

	/** The Constant TEXTURES. */
	public static final ResourceLocation TEXTURES = new ResourceLocation(
			References.MODID + ":textures/entity/testentity.png");

	/**
	 * Instantiates a new render test entity.
	 *
	 * @param manager the manager
	 */
	public RenderTestEntity(RenderManager manager) {
		super(manager, new ModelPlayer(), 0.5F);

	}

	/**
	 * Gets the entity texture.
	 *
	 * @param entity the entity
	 * @return the entity texture
	 */
	@Override
	protected ResourceLocation getEntityTexture(TestEntity entity) {
		return TEXTURES;
	}

}
