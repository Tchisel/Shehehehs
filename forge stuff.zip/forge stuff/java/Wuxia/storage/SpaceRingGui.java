package Wuxia.storage;

import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;

// TODO: Auto-generated Javadoc
/**
 * The Class SpaceRingGui.
 */
public class SpaceRingGui extends GuiContainer {

	/** The Constant guiTexture. */
	private static final ResourceLocation guiTexture = new ResourceLocation("wx:textures/gui/container/spacering.png");

	/** The inventory to render on screen. */
	private final StorageInventory inventory;

	/**
	 * Instantiates a new space ring gui.
	 *
	 * @param containerItem the container item
	 */
	public SpaceRingGui(SpaceRingContainer containerItem) {
		super(containerItem);
		this.inventory = containerItem.getInv();
		this.xSize = 176;
		this.ySize = 221;
	}

	/**
	 * Draw gui container background layer.
	 *
	 * @param partialTicks the partial ticks
	 * @param mouseX       the mouse X
	 * @param mouseY       the mouse Y
	 */
	@Override
	protected void drawGuiContainerBackgroundLayer(float partialTicks, int mouseX, int mouseY) {
		mc.getTextureManager().bindTexture(guiTexture);
		drawTexturedModalRect(guiLeft, guiTop, 0, 0, 176, 221);
	}

	/**
	 * Draw screen.
	 *
	 * @param mouseX       the mouse X
	 * @param mouseY       the mouse Y
	 * @param partialTicks the partial ticks
	 */
	@Override
	public void drawScreen(int mouseX, int mouseY, float partialTicks) {
		try {
			Slot slot;
			ItemStack itemstack;
			// this.drawDefaultBackground();
			for (int i = 0; i < 90; i++) {
				slot = this.inventorySlots.inventorySlots.get(i);
				if (slot.getStack() == null) {
					slot.putStack(ItemStack.EMPTY);
				}

			}
			super.drawScreen(mouseX, mouseY, partialTicks);
			xSize = mouseX;
			ySize = mouseY;
		} catch (Exception e) {
		}

	}
}
