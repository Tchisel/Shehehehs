package Wuxia.storage;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;

// TODO: Auto-generated Javadoc
/**
 * The Class SpaceRingContainer.
 */
public class SpaceRingContainer extends Container {

	/** The inventory. */
	private final StorageInventory inventory;

	/**
	 * Gets the inv.
	 *
	 * @return the inv
	 */
	public StorageInventory getInv() {
		return inventory;
	}

	/** The Constant INV_END. */
	private static final int HOTBAR_END = 8, HOTBAR_START = HOTBAR_END - 8, INV_START = HOTBAR_END + 27,
			INV_END = INV_START + StorageInventory.INV_SIZE;

	/**
	 * Instantiates a new space ring container.
	 *
	 * @param par1Player      the par 1 player
	 * @param inventoryPlayer the inventory player
	 * @param inventoryItem   the inventory item
	 */
	public SpaceRingContainer(EntityPlayer par1Player, InventoryPlayer inventoryPlayer,
			StorageInventory inventoryItem) {
		this.inventory = inventoryItem;
		int i;
		int id;
		int xx;
		int yy;
		Slot slot;
		// PLAYER ACTION BAR - uses default locations for standard action bar texture
		// file
		for (i = 0; i < 9; ++i) {
			this.addSlotToContainer(new Slot(inventoryPlayer, i, 8 + i * 18, 199));
		}
		// PLAYER INVENTORY - uses default locations for standard inventory texture file
		for (i = 0; i < 3; ++i) {
			for (int j = 0; j < 9; ++j) {
				id = j + i * 9 + 9;
				this.addSlotToContainer(new Slot(inventoryPlayer, id, 8 + j * 18, 140 + i * 18));
			}
		}

		// ITEM INVENTORY - you'll need to adjust the slot locations to match your
		// texture file
		// I have them set vertically in columns of 4 to the right of the player model
		for (int x = 0; x < 6; x++) {
			for (int y = 0; y < 9; y++) {
				id = y + x * 9;
				xx = 8 + y * 18;
				yy = 19 + x * 18;
				slot = new Slot(this.inventory, id, xx, yy);
				this.addSlotToContainer(slot);

			}

		}
		/*
		 * for (int k = StorageInventory.INV_SIZE - 1; k >= 0; k--) { if
		 * (this.inventory.getStackInSlot(k) == null)
		 * this.inventory.setInventorySlotContents(k, ItemStack.EMPTY); }
		 */
	}

	/**
	 * Transfer stack in slot.
	 *
	 * @param playerIn the player in
	 * @param index    the index
	 * @return the item stack
	 */
	@Override
	public ItemStack transferStackInSlot(EntityPlayer playerIn, int index) {

		ItemStack itemstack = null;
		Slot slot = this.inventorySlots.get(index);
		ItemStack itemstack1 = slot.getStack();
		itemstack = itemstack1.copy();
		Slot lowestSlot;
		Slot invSlot;
		int debug;

		if (slot != null && slot.getHasStack()) {

			// Custom item slot was clicked
			if (index > INV_START) {
				// try to place in player inventory / action bar
				if (itemstack.isStackable()) {
					debug = 36;
					for (int i = 0; i < debug; i++) {
						invSlot = this.inventorySlots.get(i);
						itemstack1 = invSlot.getStack();
						if (itemstack1.isItemEqual(itemstack) && invSlot.getStack().isStackable()
								&& invSlot.getStack().getMaxStackSize() > invSlot.getStack().getCount()) {
							mergeItemStack(itemstack, i, i + 1, true);
							slot.putStack(ItemStack.EMPTY);
							return ItemStack.EMPTY;
						}
					}
				}

				for (int i = 0; i < playerIn.inventory.getSizeInventory(); i++) {
					invSlot = this.inventorySlots.get(i);
					itemstack1 = invSlot.getStack();
					if (itemstack1.isEmpty()) {
						invSlot.putStack(itemstack);
						slot.putStack(ItemStack.EMPTY);
						return ItemStack.EMPTY;
					}
				}
			}
			if (index <= INV_START) {
				debug = this.inventory.getSizeInventory() + 36;
				if (itemstack.isStackable()) {
					for (int i = 36; i < debug; i++) {
						invSlot = this.inventorySlots.get(i);
						itemstack1 = invSlot.getStack();
						if (itemstack1.isItemEqual(itemstack) && invSlot.getStack().isStackable()
								&& invSlot.getStack().getMaxStackSize() > invSlot.getStack().getCount()) {
							mergeItemStack(itemstack, i, i + 1, true);
							slot.putStack(ItemStack.EMPTY);
							return ItemStack.EMPTY;
						}
					}
				}

				for (int i = 36; i < debug; i++) {
					invSlot = this.inventorySlots.get(i);
					itemstack1 = invSlot.getStack();
					if (itemstack1.isEmpty()) {
						invSlot.putStack(itemstack);
						slot.putStack(ItemStack.EMPTY);
						return ItemStack.EMPTY;
					}
				}
			}
		}
		return itemstack;
	}

	/**
	 * Slot click.
	 *
	 * @param slotId      the slot id
	 * @param dragType    the drag type
	 * @param clickTypeIn the click type in
	 * @param player      the player
	 * @return the item stack
	 */
	/*
	 * if (!this.mergeItemStack(itemstack1, HOTBAR_START, INV_START, true)) { return
	 * null; } slot = this.inventorySlots.get(index); return slot != null ?
	 * slot.getStack() : ItemStack.EMPTY; // slot.onSlotChange(itemstack1,
	 * itemstack); } // Item is in inventory / hotbar, try to place either in custom
	 * or armor slots
	 * 
	 * if (index <= INV_START) { // place in custom inventory if
	 * (!this.mergeItemStack(itemstack1, INV_START, INV_END, false)) { return null;
	 * } }
	 * 
	 * if (itemstack1.getCount() == 0) { // slot.putStack((ItemStack) itemstack);
	 * slot = this.inventorySlots.get(index); if (slot != null) { return
	 * slot.getStack(); } else { return ItemStack.EMPTY; } // return slot != null ?
	 * slot.getStack() : ItemStack.EMPTY; } else { slot.onSlotChanged(); }
	 * 
	 * if (itemstack1.getCount() == itemstack.getCount()) { return null; }
	 * 
	 * // slot.onPickupFromSlot(playerIn, itemstack1); }
	 * 
	 * return itemstack;
	 * 
	 * }
	 */
	@Override
	public ItemStack slotClick(int slotId, int dragType, ClickType clickTypeIn, EntityPlayer player) {
		// this will prevent the player from interacting with the item that opened the
		// inventory:
		if (slotId >= 0 && getSlot(slotId) != null && getSlot(slotId).getStack() == player.getHeldItemMainhand()) {
			return null;
		}
		ItemStack itemstack = ItemStack.EMPTY;
		InventoryPlayer inventoryplayer = player.inventory;

		if ((clickTypeIn == ClickType.PICKUP || clickTypeIn == ClickType.QUICK_MOVE)
				&& (dragType == 0 || dragType == 1)) {
			if (slotId == -999) {
				if (!inventoryplayer.getItemStack().isEmpty()) {
					if (dragType == 0) {
						player.dropItem(inventoryplayer.getItemStack(), true);
						inventoryplayer.setItemStack(ItemStack.EMPTY);
					}

					if (dragType == 1) {
						player.dropItem(inventoryplayer.getItemStack().splitStack(1), true);
					}
				}
			} else if (clickTypeIn == ClickType.QUICK_MOVE) {
				if (slotId < 0) {
					return ItemStack.EMPTY;
				}

				Slot slot5 = this.inventorySlots.get(slotId);

				if (slot5 == null || !slot5.canTakeStack(player)) {
					return ItemStack.EMPTY;
				}

				for (ItemStack itemstack7 = this.transferStackInSlot(player, slotId); !itemstack7.isEmpty()
						&& ItemStack.areItemsEqual(slot5.getStack(),
								itemstack7); itemstack7 = this.transferStackInSlot(player, slotId)) {
					itemstack = itemstack7.copy();
				}
			} else {
				if (slotId < 0) {
					return ItemStack.EMPTY;
				}

				Slot slot6 = this.inventorySlots.get(slotId);

				if (slot6 != null) {
					ItemStack itemstack8 = slot6.getStack();
					ItemStack itemstack11 = inventoryplayer.getItemStack();

					if (!itemstack8.isEmpty()) {
						itemstack = itemstack8.copy();
					}

					if (itemstack8.isEmpty()) {
						if (!itemstack11.isEmpty() && slot6.isItemValid(itemstack11)) {
							int i3 = dragType == 0 ? itemstack11.getCount() : 1;

							if (i3 > slot6.getItemStackLimit(itemstack11)) {
								i3 = slot6.getItemStackLimit(itemstack11);
							}

							slot6.putStack(itemstack11.splitStack(i3));
						}
					} else if (slot6.canTakeStack(player)) {
						if (itemstack11.isEmpty()) {
							if (itemstack8.isEmpty()) {
								slot6.putStack(ItemStack.EMPTY);
								inventoryplayer.setItemStack(ItemStack.EMPTY);
							} else {
								int l2 = dragType == 0 ? itemstack8.getCount() : (itemstack8.getCount() + 1) / 2;
								inventoryplayer.setItemStack(slot6.decrStackSize(l2));

								if (itemstack8.isEmpty()) {
									slot6.putStack(ItemStack.EMPTY);
								}

								slot6.onTake(player, inventoryplayer.getItemStack());
							}
						} else if (slot6.isItemValid(itemstack11)) {
							if (itemstack8.getItem() == itemstack11.getItem()
									&& itemstack8.getMetadata() == itemstack11.getMetadata()
									&& ItemStack.areItemStackTagsEqual(itemstack8, itemstack11)) {
								int k2 = dragType == 0 ? itemstack11.getCount() : 1;

								if (k2 > slot6.getItemStackLimit(itemstack11) - itemstack8.getCount()) {
									k2 = slot6.getItemStackLimit(itemstack11) - itemstack8.getCount();
								}

								if (k2 > itemstack11.getMaxStackSize() - itemstack8.getCount()) {
									k2 = itemstack11.getMaxStackSize() - itemstack8.getCount();
								}

								itemstack11.shrink(k2);
								itemstack8.grow(k2);
							} else if (itemstack11.getCount() <= slot6.getItemStackLimit(itemstack11)) {
								slot6.putStack(itemstack11);
								inventoryplayer.setItemStack(itemstack8);
							}
						} else if (itemstack8.getItem() == itemstack11.getItem() && itemstack11.getMaxStackSize() > 1
								&& (!itemstack8.getHasSubtypes()
										|| itemstack8.getMetadata() == itemstack11.getMetadata())
								&& ItemStack.areItemStackTagsEqual(itemstack8, itemstack11) && !itemstack8.isEmpty()) {
							int j2 = itemstack8.getCount();

							if (j2 + itemstack11.getCount() <= itemstack11.getMaxStackSize()) {
								itemstack11.grow(j2);
								itemstack8 = slot6.decrStackSize(j2);

								if (itemstack8.isEmpty()) {
									slot6.putStack(ItemStack.EMPTY);
								}

								slot6.onTake(player, inventoryplayer.getItemStack());
							}
						}
					}

					slot6.onSlotChanged();
				}
			}
			// getSlot(slotId).putStack(ItemStack.EMPTY);
			return itemstack;
		}
		return super.slotClick(slotId, dragType, clickTypeIn, player);
	}

	/**
	 * Detect and send changes.
	 */
	@Override
	public void detectAndSendChanges() {
		for (int i = 0; i < this.inventorySlots.size(); ++i) {
			try {
				ItemStack itemstack = this.inventorySlots.get(i).getStack();
				ItemStack itemstack1 = this.inventoryItemStacks.get(i);
				if (!ItemStack.areItemStacksEqual(itemstack1, itemstack)) {
					boolean clientStackChanged = !ItemStack.areItemStacksEqualUsingNBTShareTag(itemstack1, itemstack);
					itemstack1 = itemstack.isEmpty() ? ItemStack.EMPTY : itemstack.copy();
					this.inventoryItemStacks.set(i, itemstack1);

					if (clientStackChanged)
						for (int j = 0; j < this.listeners.size(); ++j) {
							this.listeners.get(j).sendSlotContents(this, i, itemstack1);
						}
				}
			} catch (Exception e) {
			}

		}
	}

	/**
	 * Can interact with.
	 *
	 * @param playerIn the player in
	 * @return true, if successful
	 */
	@Override
	public boolean canInteractWith(EntityPlayer playerIn) {
		// TODO Auto-generated method stub
		return true;
	}
}
