package Wuxia.storage;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.text.ITextComponent;

// TODO: Auto-generated Javadoc
/**
 * The Class StorageInventory.
 */
public class StorageInventory implements IInventory {

	/** The tag name. */
	private final String tagName = "alignerTag";

	/** The inv item. */
	private final ItemStack invItem;

	/** The name. */
	private String name = "Space Ring";

	/** The Constant INV_SIZE. */
	public static final int INV_SIZE = 54;

	/**
	 * Inventory's size must be same as number of slots you add to the Container
	 * class.
	 */
	private ItemStack[] inventory = new ItemStack[INV_SIZE];

	/**
	 * Instantiates a new storage inventory.
	 *
	 * @param stack the stack
	 */
	public StorageInventory(ItemStack stack) {
		invItem = stack;
		fill();
		// Create a new NBT Tag Compound if one doesn't already exist, or you will crash
		if (!stack.hasTagCompound()) {
			stack.setTagCompound(new NBTTagCompound());
		}

		// Read the inventory contents from NBT
		readFromNBT(stack.getTagCompound());
	}

	/**
	 * Fill.
	 */
	private void fill() {
		for (int i = 0; i < INV_SIZE; i++) {
			inventory[i] = ItemStack.EMPTY;
		}
	}

	/**
	 * Write to NBT.
	 *
	 * @param tagcompound the tagcompound
	 */
	private void writeToNBT(NBTTagCompound tagcompound) {
		// Create a new NBT Tag List to store itemstacks as NBT Tags
		NBTTagList items = new NBTTagList();

		for (int i = 0; i < getSizeInventory(); ++i) {
			// Only write stacks that contain items
			if (getStackInSlot(i) != null) {
				// Make a new NBT Tag Compound to write the itemstack and slot index to
				NBTTagCompound item = new NBTTagCompound();
				item.setInteger("Slot", i);
				// Writes the itemstack in slot(i) to the Tag Compound we just made
				getStackInSlot(i).writeToNBT(item);

				// add the tag compound to our tag list
				items.appendTag(item);
			}
		}
		// Add the TagList to the ItemStack's Tag Compound with the name "ItemInventory"
		tagcompound.setTag("ItemInventory", items);
	}

	/**
	 * Read from NBT.
	 *
	 * @param compound the compound
	 */
	private void readFromNBT(NBTTagCompound compound) {

		// Gets the custom taglist writte to this compound
		NBTTagList items = compound.getTagList("ItemInventory", 10);

		for (int i = 0; i < items.tagCount(); ++i) {
			NBTTagCompound item = items.getCompoundTagAt(i);
			int slot = item.getInteger("Slot");
			if (slot >= 0 && slot < getSizeInventory()) {
				inventory[slot] = new ItemStack(item);
			}
		}
	}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}

	/**
	 * Checks for custom name.
	 *
	 * @return true, if successful
	 */
	@Override
	public boolean hasCustomName() {
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * Gets the display name.
	 *
	 * @return the display name
	 */
	@Override
	public ITextComponent getDisplayName() {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * Gets the size inventory.
	 *
	 * @return the size inventory
	 */
	@Override
	public int getSizeInventory() {
		// TODO Auto-generated method stub
		return INV_SIZE;
	}

	/**
	 * Checks if is empty.
	 *
	 * @return true, if is empty
	 */
	@Override
	public boolean isEmpty() {
		for (int i = 0; i < getSizeInventory(); ++i) {
			if (this.inventory[i] != null) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Gets the stack in slot.
	 *
	 * @param index the index
	 * @return the stack in slot
	 */
	@Override
	public ItemStack getStackInSlot(int index) {
		// TODO Auto-generated method stub
		return inventory[index];
	}

	/**
	 * Decr stack size.
	 *
	 * @param index the index
	 * @param count the count
	 * @return the item stack
	 */
	@Override
	public ItemStack decrStackSize(int index, int count) {
		ItemStack stack = getStackInSlot(index);
		if (stack != null) {
			if (stack.getCount() > count) {
				stack = stack.splitStack(count);
				// Don't forget this line or your inventory will not be saved!
				this.markDirty();
			} else {
				// this method also calls onInventoryChanged, so we don't need to call it again
				setInventorySlotContents(index, null);
			}
		}
		return stack;
	}

	/**
	 * Removes the stack from slot.
	 *
	 * @param index the index
	 * @return the item stack
	 */
	@Override
	public ItemStack removeStackFromSlot(int index) {
		ItemStack stack = getStackInSlot(index);
		setInventorySlotContents(index, null);
		return stack;

	}

	/**
	 * Sets the inventory slot contents.
	 *
	 * @param index the index
	 * @param stack the stack
	 */
	@Override
	public void setInventorySlotContents(int index, ItemStack stack) {
		this.inventory[index] = stack;
		if (stack != null && stack.getCount() > this.getInventoryStackLimit()) {
			stack.setCount(this.getInventoryStackLimit());
		}

		this.markDirty();

	}

	/**
	 * Gets the inventory stack limit.
	 *
	 * @return the inventory stack limit
	 */
	@Override
	public int getInventoryStackLimit() {
		// TODO Auto-generated method stub
		return 64;
	}

	/**
	 * Checks if is usable by player.
	 *
	 * @param player the player
	 * @return true, if is usable by player
	 */
	/*
	 * @Override public void markDirty() { for (int i = 0; i < getSizeInventory();
	 * ++i) { if (getStackInSlot(i) != null && getStackInSlot(i).getCount() <= 0) {
	 * this.inventory[i] = null; } }
	 * 
	 * }
	 */
	@Override
	public boolean isUsableByPlayer(EntityPlayer player) {
		// TODO Auto-generated method stub
		return true;
	}

	/**
	 * Open inventory.
	 *
	 * @param player the player
	 */
	@Override
	public void openInventory(EntityPlayer player) {
		// TODO Auto-generated method stub

	}

	/**
	 * Close inventory.
	 *
	 * @param player the player
	 */
	@Override
	public void closeInventory(EntityPlayer player) {
		return;

	}

	/**
	 * Checks if is item valid for slot.
	 *
	 * @param index the index
	 * @param stack the stack
	 * @return true, if is item valid for slot
	 */
	@Override
	public boolean isItemValidForSlot(int index, ItemStack stack) {
		return true;
	}

	/**
	 * Gets the field.
	 *
	 * @param id the id
	 * @return the field
	 */
	@Override
	public int getField(int id) {
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * Sets the field.
	 *
	 * @param id    the id
	 * @param value the value
	 */
	@Override
	public void setField(int id, int value) {
		// TODO Auto-generated method stub

	}

	/**
	 * Gets the field count.
	 *
	 * @return the field count
	 */
	@Override
	public int getFieldCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * Clear.
	 */
	@Override
	public void clear() {
		for (int i = 0; i < inventory.length; ++i) {
			this.inventory[i] = null;
		}
	}

	/**
	 * Mark dirty.
	 */
	@Override
	public void markDirty() {
		writeToNBT(invItem.getTagCompound());
	}
}
