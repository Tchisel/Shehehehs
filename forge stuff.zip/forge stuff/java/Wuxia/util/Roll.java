package Wuxia.util;

import java.util.Random;

// TODO: Auto-generated Javadoc
/**
 * The Class Roll.
 */
public class Roll {

	/** The r. */
	Random r = new Random();

	/**
	 * Destiny roll.
	 *
	 * @return the int
	 */
	public int destinyRoll() {
		return r.nextInt(20) + 1;
	}

	/**
	 * Save roll.
	 *
	 * @param Luck the luck
	 * @return the int
	 */
	public int saveRoll(int Luck) {
		int roll = r.nextInt(100) + 1 + Luck;
		int save = r.nextInt(100) + 1;
		int cripple = r.nextInt(save) + 1;
		int death = r.nextInt(cripple) + 1;
		if (roll >= save) {
			return 1;
		} else if (roll >= cripple) {
			return 0;
		} else if (roll >= death) {
			return -1;
		}
		return 1;
	}
}