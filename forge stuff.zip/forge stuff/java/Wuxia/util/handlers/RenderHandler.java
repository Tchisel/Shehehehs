package Wuxia.util.handlers;

// TODO: Auto-generated Javadoc
/**
 * The Class RenderHandler.
 */
public class RenderHandler {

	/**
	 * links the renderclass to the Entity.
	 */
	public static void registerEntityRenders() {
		Wuxia.Wuxia.proxy.render();
	}
}
