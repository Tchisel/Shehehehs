package Wuxia.util.handlers;

import Wuxia.util.References;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.storage.loot.LootTableList;

// TODO: Auto-generated Javadoc
/**
 * The Class LootTableHandler.
 */
public class LootTableHandler {

	/** The Constant TestEntity. */
	public static final ResourceLocation TestEntity = new LootTableList()
			.register(new ResourceLocation(References.MODID, "TestEntity"));

	/** The Constant TestEntityRing. */
	public static final ResourceLocation TestEntityRing = new LootTableList()
			.register(new ResourceLocation(References.MODID, "TestEntityRing"));
}
