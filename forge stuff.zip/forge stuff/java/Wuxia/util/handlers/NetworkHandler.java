package Wuxia.util.handlers;

import Wuxia.network.MessageAbility;
import Wuxia.network.MessageEnergy;
import Wuxia.util.References;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.relauncher.Side;

public class NetworkHandler {
	private static SimpleNetworkWrapper INSTANCE;

	public static void init() {
		INSTANCE = NetworkRegistry.INSTANCE.newSimpleChannel(References.MODID);

		INSTANCE.registerMessage(MessageEnergy.class, MessageEnergy.class, 0, Side.CLIENT);
		INSTANCE.registerMessage(MessageAbility.class, MessageAbility.class, 0, Side.SERVER);
	}

	public static void sendEnergyMessage(IMessage message, EntityPlayer player) {
		INSTANCE.sendTo(message, (EntityPlayerMP) player);
	}
	public static void sendAbilityMessage(IMessage message, EntityPlayer player) {
		INSTANCE.sendTo(message, (EntityPlayerMP) player);
	}

}
