package Wuxia.util.handlers;

import Wuxia.gui.StatGui;
import Wuxia.gui.HealthGui;
import Wuxia.storage.SpaceRingContainer;
import Wuxia.storage.SpaceRingGui;
import Wuxia.storage.StorageInventory;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.network.IGuiHandler;

// TODO: Auto-generated Javadoc
/**
 * The Class GuiHandler.
 */
public class GuiHandler implements IGuiHandler {

	/** The Constant SPACERING. */
	public static final int SPACERING = 0;
	public static final int STATCHECKER = 1;
	public static final int HEALTH = 2;

	/**
	 * Gets the server gui element.
	 *
	 * @param ID     the id
	 * @param player the player
	 * @param world  the world
	 * @param x      the x
	 * @param y      the y
	 * @param z      the z
	 * @return the server gui element
	 */
	@Override
	public Object getServerGuiElement(int ID, EntityPlayer player, World world, int x, int y, int z) {
		switch (ID) {
		case SPACERING:
			return new SpaceRingContainer(player, player.inventory, new StorageInventory(player.getHeldItemMainhand()));
		case HEALTH:
			return new HealthGui(player);

		}
		return null;
	}

	/**
	 * Gets the client gui element.
	 *
	 * @param ID     the id
	 * @param player the player
	 * @param world  the world
	 * @param x      the x
	 * @param y      the y
	 * @param z      the z
	 * @return the client gui element
	 */
	@Override
	public Object getClientGuiElement(int ID, EntityPlayer player, World world, int x, int y, int z) {
		switch (ID) {
		case SPACERING:
			StorageInventory x1 = new StorageInventory(player.getHeldItemMainhand());
			SpaceRingContainer x2 = new SpaceRingContainer(player, player.inventory, x1);
			return new SpaceRingGui((x2));
		case STATCHECKER:
			return new StatGui(player);
		case HEALTH:
			return new HealthGui(player);
		}
		return null;
	}
}