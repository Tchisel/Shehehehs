package Wuxia.util.handlers;

import Wuxia.commands.CommandSetAttribute;
import Wuxia.init.BiomeInit;
import Wuxia.init.BlockInit;
import Wuxia.init.EntityInit;
import Wuxia.init.ItemInit;
import Wuxia.util.interfaces.IHasModel;
import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

// TODO: Auto-generated Javadoc
/**
 * Everything that needs to be registered in the Game Engine EventBusSubscriber
 * so it gets called in the Startup.
 *
 * @author Tchisel
 */
@EventBusSubscriber
public class RegistryHandler {

	/**
	 * Registers all items in the Arraylist ITEMS.
	 *
	 * @param event is the Item Registration event
	 */
	@SubscribeEvent
	public static void onItemRegister(RegistryEvent.Register<Item> event) {
		event.getRegistry().registerAll(ItemInit.ITEMS.toArray(new Item[0]));
	}

	/**
	 * Registers all blocks in the ArrayList BLOCKS.
	 *
	 * @param event is the RegistryEvent of Blocks
	 */
	@SubscribeEvent
	public static void onBlockRegister(RegistryEvent.Register<Block> event) {
		event.getRegistry().registerAll(BlockInit.BLOCKS.toArray(new Block[0]));
	}

	/**
	 * Pre init reg.
	 */
	public static void preInitReg() {
		EntityInit.registerEntities();
		BiomeInit.registerBiomes();
		NetworkHandler.init();
	}

	/**
	 * Registers the Models with the IHasModel registerModels.
	 *
	 * @param event is the RegistryEvent of Models
	 */
	@SubscribeEvent
	public static void onModelRegister(ModelRegistryEvent event) {
		for (Item item : ItemInit.ITEMS) {
			if (item instanceof IHasModel) {
				((IHasModel) item).registerModels();
			}
		}
		for (Block block : BlockInit.BLOCKS) {
			if (block instanceof IHasModel) {
				((IHasModel) block).registerModels();

			}
		}
	}

	public static void InitReg() {

		RenderHandler.registerEntityRenders();
	}

	public static void serverRegistries(FMLServerStartingEvent event) {
		event.registerServerCommand(new CommandSetAttribute());
	}

}
