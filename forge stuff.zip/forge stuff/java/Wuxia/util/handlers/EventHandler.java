package Wuxia.util.handlers;

import org.lwjgl.opencl.CLLinkProgramCallback;

import Wuxia.Energy.EnergyProvider;
import Wuxia.Energy.ablities.AbilityProvider;
import Wuxia.Energy.stun.IStun;
import Wuxia.Energy.stun.StundProvider;
import Wuxia.gui.HealthGui;
import Wuxia.network.MessageAbility;
import Wuxia.network.MessageEnergy;
import Wuxia.proxy.ClientProxy;
import Wuxia.proxy.CommonProxy;
import Wuxia.util.ConfigFIle;
import Wuxia.util.interfaces.IEnergy;
import Wuxia.util.interfaces.Stages;
import Wuxia.util.interfaces.Stat;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.util.DamageSource;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent.ElementType;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.event.entity.living.LivingHealEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerWakeUpEvent;
import net.minecraftforge.event.world.WorldEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent.KeyInputEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent.PlayerChangedDimensionEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent.PlayerLoggedInEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent.PlayerRespawnEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.PlayerTickEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import scala.reflect.internal.Trees.This;

// TODO: Auto-generated Javadoc
/**
 * The Class EventHandler.
 */
public class EventHandler {

	/** The world. */
	/*
	 * @SubscribeEvent public void test(EntityJoinWorldEvent event) { if
	 * (event.getEntity() instanceof EntityPlayer) { EntityPlayer player =
	 * (EntityPlayer) event.getEntity(); player.inventory = new
	 * InventoryPlyerCustom(player);
	 * 
	 * } }
	 */
	public static HealthGui healthGui;




	@SubscribeEvent
	public void onEvent(PlayerLoggedInEvent event) {
		EntityPlayer player = event.player;
		System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\tAAAAAA" );
	    
		if (player.hasCapability(EnergyProvider.energyResource, null)) {
			IEnergy energy = player.getCapability(EnergyProvider.energyResource, null);
			energy.getPlayer(player);

			NetworkHandler.sendEnergyMessage(new MessageEnergy(energy.getEnergy(), energy.getMaxEnergy(),
					player.getHealth(), player.getMaxHealth()), player);
		}
	}

	public void onEvent(PlayerRespawnEvent event) {
		EntityPlayer player = event.player;
		if (player.hasCapability(EnergyProvider.energyResource, null)) {
			IEnergy energy = player.getCapability(EnergyProvider.energyResource, null);
			energy.getPlayer(player);
			NetworkHandler.sendEnergyMessage(new MessageEnergy(energy.getEnergy(), energy.getMaxEnergy(),
					player.getHealth(), player.getMaxHealth()), player);
		}
	}

	public void onEvent(PlayerChangedDimensionEvent event) {
		EntityPlayer player = event.player;
		if (player.hasCapability(EnergyProvider.energyResource, null)) {
			IEnergy energy = player.getCapability(EnergyProvider.energyResource, null);
			energy.getPlayer(player);
			NetworkHandler.sendEnergyMessage(new MessageEnergy(energy.getEnergy(), energy.getMaxEnergy(),
					player.getHealth(), player.getMaxHealth()), player);
		}

	}

	@SubscribeEvent
	public void onEvent(LivingHealEvent event) {
		Entity receiver = event.getEntity();
		if (!world.isRemote) {
			if (receiver != null) {
				float amount = event.getAmount();
				int vitality = 1;
				if (receiver.hasCapability(EnergyProvider.energyResource, null)) {
					IEnergy energy = receiver.getCapability(EnergyProvider.energyResource, null);
					vitality = energy.getStat(Stat.VITALITY);
					amount = amount * vitality;
					event.setAmount(amount);
				}

			}
		}
	}

	@SubscribeEvent
	public void onEvent(RenderGameOverlayEvent event) {
		if (event.getType() == ElementType.TEXT) {
			if (Minecraft.getMinecraft().player.hasCapability(EnergyProvider.energyResource, null))
				// event.setCanceled(true);
				healthGui = new HealthGui(Minecraft.getMinecraft().player);
			healthGui.renderOverlayBar();
			healthGui.renderOverlayText();
		}
		if (event.getType() == ElementType.HEALTH) {
			event.setCanceled(true);
		}
	}

	@SubscribeEvent
	public void onEvent(PlayerTickEvent event) {
		if (event.side.isClient()) {
			// event.player.openGui(Wuxia.instance, GuiHandler.HEALTH,
			// event.player.getEntityWorld(), 0, 0, 0);
		} else {
			try {
				EntityPlayer playerServer = event.player;
				if (event.player.hasCapability(EnergyProvider.energyResource, null)) {
					IEnergy energy = playerServer.getCapability(EnergyProvider.energyResource, null);
					if (energy.getStage() != Stages.MORTAL && energy.getStage() != Stages.XIANTIAN) {
						if (playerServer.getFoodStats().needFood())
							playerServer.getFoodStats().addStats(20, 2.0f);
						;
					}

				}
			}

			catch (Exception e) {
			}
		}
	}

	@SubscribeEvent
	public void onEvent(LivingDamageEvent event) {
		Entity inflictor = event.getSource().getImmediateSource();
		Entity receiver = event.getEntity();

		if (event.getSource() == DamageSource.DROWN) {
			if (receiver.hasCapability(EnergyProvider.energyResource, null)) {
				IEnergy energyR = receiver.getCapability(EnergyProvider.energyResource, null);
				if (energyR.getEnergy() >= 10) {
					energyR.decreaseEnergy(10);
					event.setCanceled(true);
				}

			}
		}

		if (inflictor != null && receiver != null) {
			if (event.getSource().isProjectile()) {
				inflictor = event.getSource().getTrueSource();
			}
			int damageMod = 1;
			int vitalityMod = 1;
			float damage = event.getAmount();
			if (inflictor.hasCapability(EnergyProvider.energyResource, null)) {
				IEnergy energyI = inflictor.getCapability(EnergyProvider.energyResource, null);
				damageMod = energyI.getStat(Stat.STRENTGH);
			}
			if (receiver.hasCapability(EnergyProvider.energyResource, null)) {
				IEnergy energyR = receiver.getCapability(EnergyProvider.energyResource, null);
				vitalityMod = energyR.getStat(Stat.VITALITY);
			}
			damage = ((damage * damageMod) / vitalityMod);
			event.setAmount(damage);
		}
		if (receiver instanceof EntityPlayer) {
			if (receiver.hasCapability(EnergyProvider.energyResource, null)) {
				IEnergy energy = receiver.getCapability(EnergyProvider.energyResource, null);
				EntityPlayer player = (EntityPlayer) receiver;
				NetworkHandler.sendEnergyMessage(new MessageEnergy(energy.getEnergy(), energy.getMaxEnergy(),
						player.getHealth(), player.getMaxHealth()), player);
			}
		}
	}

	private static World world;

	@SubscribeEvent
	public void tickEntity(PlayerTickEvent event) {
		// if (event.player.world.isRemote) {
		EntityPlayer player = event.player;
		IStun stun = player.getCapability(StundProvider.stunResource, null);
		IEnergy energy = player.getCapability(EnergyProvider.energyResource, null);
		if (stun.getIsStunnned()) {
			stun.setTickStunned(stun.getTickStunned() + 1);
			if (stun.getTickStunned() >= stun.getstunDuration()) {
				stun.setIsStunnned(false);
				stun.setTickStunned(0);
				stun.setstunDuration(0);
				return;
			}
			KeyBinding.unPressAllKeys();
		}
	}
	
	
	

	// }
	/**
	 * Gets the wold.
	 *
	 * @return the wold
	 */
	public static World getWold() {
		return world;
	}

	/**
	 * On world load.
	 *
	 * @param event the event
	 */
	@SubscribeEvent
	public void onWorldLoad(WorldEvent.Load event) {
		this.world = event.getWorld();
	}

	/**
	 * On player logs in.
	 *
	 * @param event the event
	 */
	@SubscribeEvent
	public void onPlayerLogsIn(PlayerLoggedInEvent event) {
		if (event.player.world.isRemote) {
			EntityPlayer player = event.player;
			IEnergy energy = player.getCapability(EnergyProvider.energyResource, null);
			if (cultivator(energy)) {
				String message = String.format("Hello there, you have �7%d�r energy left.", energy.getMaxEnergy());
				player.sendMessage(new TextComponentString(message));
			}
		}
	}

	/**
	 * On player sleep.
	 *
	 * @param event the event
	 */
	@SubscribeEvent
	public void onPlayerSleep(PlayerWakeUpEvent event) {

		EntityPlayer player = event.getEntityPlayer();
		IEnergy energy = player.getCapability(EnergyProvider.energyResource, null);

		if (player.world.isRemote)
			return;
		else if (cultivator(energy)) {
			int sleepincrease = 20 * energy.getLatentTalent();
			energy.increaseEnergy(20 * energy.getLatentTalent(), player);

			String message = String.format(
					"You refreshed yourself in the bed. You received �7%d�r mana, you have �7%d�r energy left.",
					sleepincrease, energy.getEnergy());
			player.sendMessage(new TextComponentString(message));
		}
	}
	
	@SubscribeEvent
	public void onEvent(KeyInputEvent event)
	{
		System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\tAAAAAA" );
	    KeyBinding[] keyBindings = ClientProxy.keyBindings;
	    EntityPlayer player = Minecraft.getMinecraft().player;
	    if (keyBindings[0].isPressed()) 

	    {
	    	NetworkHandler.sendAbilityMessage(
					new MessageAbility(), player);
	
			
	}
		}


	/**
	 * On player falls.
	 *
	 * @param event the event
	 */
	@SubscribeEvent
	public void onPlayerFalls(LivingFallEvent event) {
		if (world.isRemote) {
			Entity entity = event.getEntity();

			if (entity.world.isRemote || !(entity instanceof EntityPlayerMP) || event.getDistance() < 3)
				return;
			EntityPlayer player = (EntityPlayer) entity;
			IEnergy energy = player.getCapability(EnergyProvider.energyResource, null);
			if (cultivator(energy) || !energy.getGc()) {
				int points = energy.getEnergy();
				float amount = event.getDistance() * 2;
				int dmg = Math.round(amount);

				if (points > dmg) {
					energy.decreaseEnergy(dmg);
					event.setCanceled(true);
				}
			}
		}
	}

	/**
	 * Cultivator.
	 *
	 * @param energy the energy
	 * @return true, if successful
	 */
	public boolean cultivator(IEnergy energy) {

		switch (energy.getAlive()) {
		case 1:
			return true;
		default:
			return false;
		}

	}

	/**
	 * Copy data from dead player to the new player.
	 *
	 * @param event the event
	 */
	@SubscribeEvent
	public void onPlayerClone(PlayerEvent.Clone event) {
		if (event.getEntityPlayer().world.isRemote) {
			if (!ConfigFIle.looseStatsOnDeath) {
				EntityPlayer player = event.getEntityPlayer();
				IEnergy energy = player.getCapability(EnergyProvider.energyResource, null);
				IEnergy oldEnergy = event.getOriginal().getCapability(EnergyProvider.energyResource, null);

				energy.setAllValues(oldEnergy.getAllValues());
			}
		}
	}

}
