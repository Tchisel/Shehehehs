package Wuxia.util.interfaces;

import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.world.WorldServer;
import net.minecraft.world.gen.structure.template.PlacementSettings;
import net.minecraftforge.fml.common.FMLCommonHandler;

// TODO: Auto-generated Javadoc
/**
 * The Interface IStructure.
 */
public interface IStructure {
	
	/** The Constant worldServer. */
	public static final WorldServer worldServer = FMLCommonHandler.instance().getMinecraftServerInstance().getWorld(0);
	
	/** The Constant setting. */
	public static final PlacementSettings setting = (new PlacementSettings()).setChunk(null).setIgnoreEntities(false)
			.setIgnoreStructureBlock(false).setMirror(Mirror.NONE).setRotation(Rotation.NONE);
}