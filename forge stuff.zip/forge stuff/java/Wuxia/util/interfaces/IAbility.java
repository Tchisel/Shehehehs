package Wuxia.util.interfaces;

import java.util.ArrayList;

import Wuxia.Energy.ablities.AbilitiesEnum;
import net.minecraft.entity.Entity;
import net.minecraft.world.World;

public interface IAbility {

	void slotUp();

	void slotDown();

	void setSlot(int slot, AbilitiesEnum ability);

	boolean addAbility(AbilitiesEnum ability);

	AbilitiesEnum getEquippedAbility();

	boolean removeAbility(AbilitiesEnum ability);

	boolean fireEquippedAbility(Entity caster, World world);

	void setHighestIndex(int value);

	void setCurrentIndex(int value);

	int getHighestIndex();

	int getCurrentIndex();

	ArrayList<AbilitiesEnum> getAbilities();
}
