package Wuxia.util.interfaces;

// TODO: Auto-generated Javadoc
/**
 * Used fore Registering Models.
 *
 * @author Tchisel
 */
public interface IHasModel {
	/**
	 * Function needed to register Models.
	 */
	public void registerModels();
}
