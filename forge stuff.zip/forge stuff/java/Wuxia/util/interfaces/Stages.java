package Wuxia.util.interfaces;

public enum Stages {
	MORTAL("MORTAL"), XIANTIAN("XIANTIAN"), QICONDENSATION("QICONDENSATION"), ZIFUDISCIPLE("ZIFUDISCIPLE"),
	JINDANIMMORTAL("JINDANIMMORTAL");

	private final String stage;

	Stages(String i) {
		stage = i;
	}

	public String getStat() {
		return stage;
	}
}
