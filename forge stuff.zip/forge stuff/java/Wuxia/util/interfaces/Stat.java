package Wuxia.util.interfaces;

public enum Stat {
	STRENTGH(0), VITALITY(1), SPEED(2), SPIRIT(2), DIVINESENSE(4);

	private final int StatMan;

	Stat(int i) {
		StatMan = i;
	}

	public int getStat() {
		return StatMan;
	}
}
