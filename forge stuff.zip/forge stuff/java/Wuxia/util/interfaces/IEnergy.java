package Wuxia.util.interfaces;

import Wuxia.Energy.Energy;
import net.minecraft.entity.player.EntityPlayer;

// TODO: Auto-generated Javadoc
/**
 * The Interface IEnergy.
 */
public interface IEnergy {

	int getStat(Stat stat);

	void setStat(Stat stat, int value);

	Stages getStage();

	void setStage(Stages stage);

	boolean increaseStage(int energyOverflow, EntityPlayer player);

	void decreaseStage(int energyOverflow, EntityPlayer player);

	void sendChanges(EntityPlayer player);

	int getLastLevelUp();

	void setLastLevelUp(int energy);

	int getStageLimit(Stages stage2);

	/**
	 * Gets the energy.
	 *
	 * @return the energy
	 */
	int getEnergy();

	/**
	 * Gets the max energy.
	 *
	 * @return the max energy
	 */
	int getMaxEnergy();

	/**
	 * Sets the max energy.
	 *
	 * @param amount the new max energy
	 */
	void setMaxEnergy(int amount);

	/**
	 * Gets the luck.
	 *
	 * @return the luck
	 */
	int getLuck();

	/**
	 * Sets the luck.
	 *
	 * @param amount the new luck
	 */
	void setLuck(int amount);

	/**
	 * Gets the latent talent.
	 *
	 * @return the latent talent
	 */
	int getLatentTalent();

	/**
	 * Sets the latent talent.
	 *
	 * @param amount the new latent talent
	 */
	void setLatentTalent(int amount);

	/**
	 * Sets the energy.
	 *
	 * @param amount the new energy
	 */
	void setEnergy(int amount);

	/**
	 * Increase energy.
	 *
	 * @param amount the amount
	 * @return the int
	 */
	int increaseEnergy(int amount, EntityPlayer player);

	/**
	 * Decrease energy.
	 *
	 * @param amount the amount
	 * @return the int
	 */
	int decreaseEnergy(int amount);

	/**
	 * Increase max energy.
	 *
	 * @param amount the amount
	 */
	void increaseMaxEnergy(int amount);

	/**
	 * Decrease max energy.
	 *
	 * @param amount the amount
	 */
	void decreaseMaxEnergy(int amount);

	/**
	 * Gets the alive.
	 *
	 * @return the alive
	 */
	int getAlive();

	/**
	 * Sets the alive.
	 *
	 * @param alive the new alive
	 */
	void setAlive(int alive);

	/**
	 * Gets the all values.
	 *
	 * @return the all values
	 */
	Energy getAllValues();

	/**
	 * Sets the all values.
	 *
	 * @param energy the new all values
	 */
	void setAllValues(Energy energy);

	/**
	 * Gets the gc.
	 *
	 * @return the gc
	 */
	boolean getGc();

	/**
	 * Sets the gc.
	 *
	 * @param gc the new gc
	 */
	void setGc(boolean gc);

	void applyVitality(EntityPlayer player, int increase);

	void getPlayer(EntityPlayer player);
}
