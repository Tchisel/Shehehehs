package Wuxia.util;

import net.minecraftforge.common.config.Config;

// TODO: Auto-generated Javadoc
/**
 * The Class ConfigFIle.
 */
@Config(modid = References.MODID)
@Config.LangKey("wx.config.title")
public class ConfigFIle {

	/** The loose stats on death. */
	@Config.Comment("When true, looses all stats on death. When false, keeps all stats on death")
	public static boolean looseStatsOnDeath = true;

}
