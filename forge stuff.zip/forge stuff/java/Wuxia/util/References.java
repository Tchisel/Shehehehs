package Wuxia.util;

// TODO: Auto-generated Javadoc
/**
 * Just some References.
 *
 * @author Tchisel
 */
public class References {

	/** The Constant MODID. */
	public static final String MODID = "wx";

	/** The Constant NAME. */
	public static final String NAME = "Wuxia";

	/** The Constant VERSION. */
	public static final String VERSION = "1.0.0";

	/** The Constant COMMON. */
	public static final String COMMON = "Wuxia.proxy.CommonProxy";

	/** The Constant CLIENT. */
	public static final String CLIENT = "Wuxia.proxy.ClientProxy";

	/** The Constant TEST_ENTITY. */
	public static final int TEST_ENTITY = 0;
	public static final int FIREBALL = 1;

}
