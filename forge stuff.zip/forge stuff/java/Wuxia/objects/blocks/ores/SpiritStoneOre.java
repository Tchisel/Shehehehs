package Wuxia.objects.blocks.ores;

import Wuxia.Wuxia;
import Wuxia.init.BlockInit;
import Wuxia.init.ItemInit;
import Wuxia.objects.blocks.BlockOreole;
import Wuxia.objects.items.SpiritStone.StoneQuality;
import Wuxia.util.interfaces.IHasModel;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;

public class SpiritStoneOre extends Block implements IHasModel, BlockOreole {
	private StoneQuality stoneQuality;

	public SpiritStoneOre(String name, StoneQuality quality, Material material) {
		super(material);
		this.stoneQuality = quality;
		setUnlocalizedName(name);
		setRegistryName(name);
		setCreativeTab(Wuxia.testtab);

		BlockInit.BLOCKS.add(this);
		ItemInit.ITEMS.add(new ItemBlock(this).setRegistryName(this.getRegistryName()));
	}

	@Override
	public int MAXHEIGHT() {
		// TODO Auto-generated method stub
		return 50;
	}

	@Override
	public int MINHEIGHT() {
		// TODO Auto-generated method stub
		return 1;
	}

	@Override
	public int CHANCE() {
		switch (stoneQuality) {
		case HIGH:
			return 2;
		case LOW:
			return 4;
		case MEDIUM:
			return 3;
		case TOP:
			return 1;
		default:
			return 0;
		}
	}

	@Override
	public int GENERATESIN() {
		// TODO Auto-generated method stub
		return 1;
	}

	@Override
	public void registerModels() {
		Wuxia.proxy.registerItemRenderer(Item.getItemFromBlock(this), 0, "inventory");

	}
}
