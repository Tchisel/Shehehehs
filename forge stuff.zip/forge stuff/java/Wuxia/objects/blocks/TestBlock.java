package Wuxia.objects.blocks;

import Wuxia.Wuxia;
import Wuxia.init.BlockInit;
import Wuxia.init.ItemInit;
import Wuxia.util.interfaces.IHasModel;
import net.minecraft.block.Block;
import net.minecraft.block.material.MapColor;
import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.world.gen.structure.template.Template.BlockInfo;

// TODO: Auto-generated Javadoc
/**
 * Class for the Block TestBlock.
 *
 * @author Tchisel
 */
public class TestBlock extends Block implements IHasModel, BlockOreole {
	
	/**
	 * Instantiates a new test block.
	 *
	 * @param name     unlocalised Name
	 * @param material what sound it will make when stepped on an broken
	 */
	public TestBlock(String name, Material material) {
		super(material);
		setUnlocalizedName(name);
		setRegistryName(name);
		setCreativeTab(Wuxia.testtab);

		BlockInit.BLOCKS.add(this);
		ItemInit.ITEMS.add(new ItemBlock(this).setRegistryName(this.getRegistryName()));
	}

	/**
	 * Registers the Model.
	 */
	@Override
	public void registerModels() {
		Wuxia.proxy.registerItemRenderer(Item.getItemFromBlock(this), 0, "inventory");
	}

	/**
	 * Maxheight.
	 *
	 * @return the int
	 */
	@Override
	public int MAXHEIGHT() {
		// TODO Auto-generated method stub
		return 52;
	}

	/**
	 * Minheight.
	 *
	 * @return the int
	 */
	@Override
	public int MINHEIGHT() {
		// TODO Auto-generated method stub
		return 1;
	}

	/**
	 * Chance.
	 *
	 * @return the int
	 */
	@Override
	public int CHANCE() {
		// TODO Auto-generated method stub
		return 3;
	}

	/**
	 * Generatesin.
	 *
	 * @return the int
	 */
	@Override
	public int GENERATESIN() {
		// TODO Auto-generated method stub
		return 1;
	}

}
