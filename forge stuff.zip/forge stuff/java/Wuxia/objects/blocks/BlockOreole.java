package Wuxia.objects.blocks;

// TODO: Auto-generated Javadoc
/**
 * The Interface BlockOreole.
 */
public interface BlockOreole {

	/**
	 * Maxheight.
	 *
	 * @return the int
	 */
	int MAXHEIGHT();

	/**
	 * Minheight.
	 *
	 * @return the int
	 */
	int MINHEIGHT();

	/**
	 * Chance.
	 *
	 * @return the int
	 */
	int CHANCE();

	/**
	 * Generatesin.
	 *
	 * @return the int
	 */
	int GENERATESIN();

}
