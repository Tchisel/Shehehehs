package Wuxia.objects.items.SpiritStone;

import Wuxia.Wuxia;
import Wuxia.Energy.EnergyProvider;
import Wuxia.init.ItemInit;
import Wuxia.util.interfaces.IEnergy;
import Wuxia.util.interfaces.IHasModel;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.world.World;

// TODO: Auto-generated Javadoc
/**
 * The Class ItemTest.
 */
public class SpiritStone extends Item implements IHasModel {

	/**
	 * makes the Item appear ingame.
	 *
	 * @param name is the registration name/ unlocalized name
	 */
	private int itemDamage;
	private int quality;
	private StoneQuality stoneQuality;

	public SpiritStone(String name, StoneQuality quality) {
		setUnlocalizedName(name);
		setRegistryName(name);
		setCreativeTab(Wuxia.testtab);
		setNoRepair();
		setMaxDamage(5);
		this.quality = quality.getStoneQuality();
		this.stoneQuality = quality;
		ItemInit.ITEMS.add(this);

	}

	@Override
	public int getMetadata(ItemStack stack) {
		return itemDamage;
	}

	@Override
	public ActionResult<ItemStack> onItemRightClick(World worldIn, EntityPlayer playerIn, EnumHand handIn) {
		ItemStack item = playerIn.getHeldItemMainhand();
		IEnergy energy = playerIn.getCapability(EnergyProvider.energyResource, null);
		energy.increaseEnergy(quality * energy.getLatentTalent(), playerIn);
		if (playerIn.capabilities.isCreativeMode) {
			return new ActionResult(EnumActionResult.SUCCESS, item);
		} else {
			int x = item.getCount();
			item = new ItemStack(ItemInit.SPRIT_STONE, x - 1, item.getItemDamage());
			ItemStack newItem = new ItemStack(ItemInit.getStone(stoneQuality, false), 1, item.getItemDamage() + 1);
			// newItem.getItem().setMaxStackSize(1);
			if (item.getItemDamage() >= newItem.getMaxDamage()) {
				return new ActionResult(EnumActionResult.SUCCESS, ItemStack.EMPTY);
			}
			if (x == 1) {
				return new ActionResult(EnumActionResult.SUCCESS, newItem);
			}
			playerIn.addItemStackToInventory(newItem);
			return new ActionResult(EnumActionResult.SUCCESS, item);
		}
	}

	// itemDamage = item.getItemDamage() + 1;
	// item.setCount(item.getCount() - 1);

	/**
	 * Registers the model so it has an appearance.
	 */
	@Override
	public void registerModels() {
		Wuxia.proxy.registerItemRenderer(this, 0, "inventory");
	}

}
