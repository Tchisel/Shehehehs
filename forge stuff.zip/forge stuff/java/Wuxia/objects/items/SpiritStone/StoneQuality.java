package Wuxia.objects.items.SpiritStone;

public enum StoneQuality {
	LOW(50), MEDIUM(500), HIGH(5000), TOP(50000);

	private final int StoneQuality;

	StoneQuality(int i) {
		StoneQuality = i;
	}

	public int getStoneQuality() {
		return StoneQuality;
	}
}
