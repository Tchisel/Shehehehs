package Wuxia.objects.items.SpiritStone;

import Wuxia.Wuxia;
import Wuxia.Energy.EnergyProvider;
import Wuxia.init.ItemInit;
import Wuxia.util.interfaces.IEnergy;
import Wuxia.util.interfaces.IHasModel;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.world.World;

public class SpiritStoneUsed extends Item implements IHasModel {

	/**
	 * makes the Item appear ingame.
	 *
	 * @param name is the registration name/ unlocalized name
	 */
	private int itemDamage;
	private int quality;
	private StoneQuality stoneQuality;

	public SpiritStoneUsed(String name, StoneQuality quality) {
		setUnlocalizedName(name);
		setRegistryName(name);
		setNoRepair();
		setMaxDamage(5);
		setMaxStackSize(1);
		this.quality = quality.getStoneQuality();
		this.stoneQuality = quality;
		ItemInit.ITEMS.add(this);

	}

	@Override
	public int getMetadata(ItemStack stack) {
		return itemDamage;
	}

	@Override
	public ActionResult<ItemStack> onItemRightClick(World worldIn, EntityPlayer playerIn, EnumHand handIn) {
		ItemStack item = playerIn.getHeldItemMainhand();
		IEnergy energy = playerIn.getCapability(EnergyProvider.energyResource, null);
		energy.increaseEnergy(quality * energy.getLatentTalent(), playerIn);
		if (playerIn.capabilities.isCreativeMode) {
			return new ActionResult(EnumActionResult.SUCCESS, item);
		} else {
			ItemStack newItem = new ItemStack(ItemInit.getStone(stoneQuality, true), 1, item.getItemDamage() + 1);
			if (newItem.getItemDamage() >= newItem.getMaxDamage()) {
				return new ActionResult(EnumActionResult.SUCCESS, ItemStack.EMPTY);
			}
			return new ActionResult(EnumActionResult.SUCCESS, newItem);
		}
	}

	private int getQuality() {
		switch (stoneQuality) {
		case HIGH:
			return 2;
		case LOW:
			return 0;
		case MEDIUM:
			return 1;
		case TOP:
			return 3;
		default:
			return 0;

		}
	}

	/**
	 * Registers the model so it has an appearance.
	 */
	@Override
	public void registerModels() {
		Wuxia.proxy.registerItemRenderer(this, 0, "inventory");
	}
}