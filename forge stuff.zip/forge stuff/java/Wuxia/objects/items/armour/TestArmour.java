package Wuxia.objects.items.armour;

import Wuxia.Wuxia;
import Wuxia.init.ItemInit;
import Wuxia.util.interfaces.IHasModel;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor;
// TODO: Auto-generated Javadoc

/**
 * custom armour.
 *
 * @author Tchisel
 */
public class TestArmour extends ItemArmor implements IHasModel{

/**
 * Makes the Armour appear ingame.
 *
 * @param name is the unlocalised registration name
 * @param materialIn the material its made of Helath/DMGabsorbtion
 * @param renderIndexIn 3dRender
 * @param equipmentSlotIn where it goes in the Inventory
 */
	public TestArmour(String name, ArmorMaterial materialIn, int renderIndexIn, EntityEquipmentSlot equipmentSlotIn) {
		super(materialIn, renderIndexIn, equipmentSlotIn);
		setUnlocalizedName(name);
		setRegistryName(name);
		setCreativeTab(Wuxia.testtab);
		
		ItemInit.ITEMS.add(this);
		
	}
	
	/**
	 * Register models.
	 */
	@Override
	public void registerModels() {
		Wuxia.proxy.registerItemRenderer(this, 0, "inventory");
	}
	

}
