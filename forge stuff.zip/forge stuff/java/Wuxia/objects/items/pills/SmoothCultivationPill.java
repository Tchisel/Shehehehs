package Wuxia.objects.items.pills;

import Wuxia.Wuxia;
import Wuxia.Energy.EnergyProvider;
import Wuxia.Energy.stun.IStun;
import Wuxia.Energy.stun.StundProvider;
import Wuxia.init.ItemInit;
import Wuxia.util.interfaces.IEnergy;
import Wuxia.util.interfaces.IHasModel;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.world.World;

public class SmoothCultivationPill extends Item implements IHasModel {

	/**
	 * makes the Item appear ingame.
	 *
	 * @param name is the registration name/ unlocalized name
	 */
	public SmoothCultivationPill(String name) {
		setUnlocalizedName(name);
		setRegistryName(name);
		setCreativeTab(Wuxia.testtab);

		ItemInit.ITEMS.add(this);

	}

	Quality PillQuality = Quality.STANDART;

	/**
	 * Registers the model so it has an appearance.
	 */
	@Override
	public void registerModels() {
		Wuxia.proxy.registerItemRenderer(this, 0, "inventory");
	}

	@Override
	public ActionResult<ItemStack> onItemRightClick(World worldIn, EntityPlayer playerIn, EnumHand handIn) {
		ItemStack item = playerIn.getHeldItemMainhand();
		IStun stun = playerIn.getCapability(StundProvider.stunResource, null);
		IEnergy energy = playerIn.getCapability(EnergyProvider.energyResource, null);
		stun.setstunDuration(
				stun.getstunDuration() / (((energy.getLatentTalent() + 1) * PillQuality.getPillQuality())));
		item.setCount(item.getCount() - 1);
		return new ActionResult(EnumActionResult.SUCCESS, item);
	}

}
