package Wuxia.objects.items.pills;

public enum Quality {
	LOW(1), STANDART(2), MEDIUM(5), HIGH(10), SUPERIOUR(50), PERFECT(100);

	private final int PillQuality;

	Quality(int i) {
		PillQuality = i;
	}

	public int getPillQuality() {
		return PillQuality;
	}
}
