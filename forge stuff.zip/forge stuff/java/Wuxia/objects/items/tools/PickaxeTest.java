package Wuxia.objects.items.tools;

import Wuxia.Wuxia;
import Wuxia.init.ItemInit;
import Wuxia.util.interfaces.IHasModel;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPickaxe;
// TODO: Auto-generated Javadoc

/**
 * custom tool.
 *
 * @author Tchisel
 */
public class PickaxeTest extends ItemPickaxe implements IHasModel{
	
	/**
	 * Makes the Item appear ingame.
	 *
	 * @param name is the unlocalised registration name
	 * @param material what is it made of, DMG/Speed/Health
	 */
	public PickaxeTest(String name, ToolMaterial material) {
		super(material);
		setUnlocalizedName(name);
		setRegistryName(name);
		setCreativeTab(Wuxia.testtab);
		
		ItemInit.ITEMS.add(this);
		
	}
	
	/**
	 * Registers the model so it has an appearance.
	 */
	@Override
	public void registerModels() {
		Wuxia.proxy.registerItemRenderer(this, 0, "inventory");
	}
	
}
