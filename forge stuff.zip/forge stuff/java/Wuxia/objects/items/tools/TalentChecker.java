package Wuxia.objects.items.tools;

import Wuxia.Wuxia;
import Wuxia.Energy.EnergyProvider;
import Wuxia.init.ItemInit;
import Wuxia.util.interfaces.IEnergy;
import Wuxia.util.interfaces.IHasModel;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;

// TODO: Auto-generated Javadoc
/**
 * The Class TalentChecker.
 */
public class TalentChecker extends Item implements IHasModel {

	/** The uses. */
	int uses = 15;

	/**
	 * makes the Item appear ingame.
	 *
	 * @param name is the registration name/ unlocalized name
	 */
	public TalentChecker(String name) {
		setUnlocalizedName(name);
		setRegistryName(name);
		setCreativeTab(Wuxia.testtab);

		ItemInit.ITEMS.add(this);

	}

	/**
	 * Registers the model so it has an appearance.
	 */
	@Override
	public void registerModels() {
		Wuxia.proxy.registerItemRenderer(this, 0, "inventory");
	}

	/**
	 * On item right click.
	 *
	 * @param worldIn the world in
	 * @param player  the player
	 * @param handIn  the hand in
	 * @return the action result
	 */
	@Override
	public ActionResult<ItemStack> onItemRightClick(World worldIn, EntityPlayer player, EnumHand handIn) {
		IEnergy energy = player.getCapability(EnergyProvider.energyResource, null);
		if (!worldIn.isRemote) {
			String stage;
			switch (energy.getStage()) {
			case JINDANIMMORTAL:
				stage = "Jindan Immortal";
				break;
			case MORTAL:
				stage = "Mortal";
				break;
			case QICONDENSATION:
				stage = "Qi Condensation";
				break;
			case XIANTIAN:
				stage = "Xiantian";
				break;
			case ZIFUDISCIPLE:
				stage = "Zifu Disciple";
				break;
			default:
				stage = "Mortal";
				break;

			}
			String latentTalent = Integer.toString(energy.getLatentTalent());
			String maxEnergy = Integer.toString(energy.getMaxEnergy());
			String Energy = Integer.toString(energy.getEnergy());
			String message = String.format("Your latent talent is " + latentTalent + "\nYour maximum energy is "
					+ maxEnergy + ", you have " + Energy + " energy left.\nYour Stage is " + stage);
			player.sendMessage(new TextComponentString(message));
		}
		return super.onItemRightClick(worldIn, player, handIn);

	}
}
