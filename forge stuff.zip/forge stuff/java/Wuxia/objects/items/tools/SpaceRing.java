package Wuxia.objects.items.tools;

import java.util.ArrayList;

import Wuxia.Wuxia;
import Wuxia.init.ItemInit;
import Wuxia.storage.StorageInventory;
import Wuxia.util.handlers.GuiHandler;
import Wuxia.util.interfaces.IHasModel;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.world.World;

// TODO: Auto-generated Javadoc
/**
 * The Class SpaceRing.
 */
public class SpaceRing extends Item implements IHasModel {

	/** The item stack. */
	ArrayList<ItemStack> itemStack = new ArrayList<ItemStack>();

	/** The item counter. */
	int itemCounter = 0;

	/** The st. */
	private StorageInventory st;

	/** The capabilities. */
	private net.minecraftforge.common.capabilities.CapabilityDispatcher capabilities;

	/**
	 * makes the Item appear ingame.
	 *
	 * @param name is the registration name/ unlocalized name
	 */
	public SpaceRing(String name) {

		setUnlocalizedName(name);
		setRegistryName(name);
		setCreativeTab(Wuxia.testtab);
		ItemInit.ITEMS.add(this);
		setMaxStackSize(1);
	}

	/**
	 * Gets the storage inventory.
	 *
	 * @return the storage inventory
	 */
	public StorageInventory getStorageInventory() {
		return st;

	}

	/**
	 * Registers the model so it has an appearance.
	 */
	@Override
	public void registerModels() {
		Wuxia.proxy.registerItemRenderer(this, 0, "inventory");
	}

	/**
	 * On item right click.
	 *
	 * @param world  the world
	 * @param player the player
	 * @param handIn the hand in
	 * @return the action result
	 */
	@Override
	public ActionResult<ItemStack> onItemRightClick(World world, EntityPlayer player, EnumHand handIn) {
		if (!world.isRemote) {
			// If player not sneaking, open the inventory gui
			if (!player.isSneaking()) {
				player.openGui(Wuxia.instance, GuiHandler.SPACERING, world, 0, 0, 0);
			}
		}

		return super.onItemRightClick(world, player, handIn);
	}

	/*
	 * playerIn.openGui(Wuxia.instance,0,worldIn,playerIn.chunkCoordX,playerIn.
	 * chunkCoordY,playerIn.chunkCoordZ);
	 * 
	 * return super.onItemRightClick(worldIn,playerIn,handIn);
	 */
}
