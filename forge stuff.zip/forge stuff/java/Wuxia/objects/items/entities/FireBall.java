package Wuxia.objects.items.entities;

import Wuxia.Wuxia;
import Wuxia.Energy.ablities.AbilitiesEnum;
import Wuxia.Energy.ablities.AbilityProvider;
import Wuxia.init.ItemInit;
import Wuxia.util.interfaces.IAbility;
import Wuxia.util.interfaces.IHasModel;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.world.World;

public class FireBall extends Item implements IHasModel {

	/**
	 * makes the Item appear ingame.
	 *
	 * @param name is the registration name/ unlocalized name
	 */
	public FireBall(String name) {
		setUnlocalizedName(name);
		setRegistryName(name);
		setMaxStackSize(1);
		ItemInit.ITEMS.add(this);
	}

	@Override
	public void registerModels() {
		Wuxia.proxy.registerItemRenderer(this, 0, "inventory");
	}

	@Override
	public ActionResult<ItemStack> onItemRightClick(World worldIn, EntityPlayer player, EnumHand handIn) {
		if (!worldIn.isRemote) {
			if (player.hasCapability(AbilityProvider.abilityResource, null)) {
				IAbility ability = player.getCapability(AbilityProvider.abilityResource, null);
				ability.addAbility(AbilitiesEnum.FIREBALL);
				ability.fireEquippedAbility(player, worldIn);
			}

		}
		return new ActionResult(EnumActionResult.SUCCESS, ItemStack.EMPTY);

	}
}
