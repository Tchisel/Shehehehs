package Wuxia.objects.items;

import Wuxia.Wuxia;
import Wuxia.init.ItemInit;
import Wuxia.util.interfaces.IHasModel;
import net.minecraft.item.Item;

// TODO: Auto-generated Javadoc
/**
 * The Class ItemTest.
 */
public class ItemTest extends Item implements IHasModel {
	
	/**
	 * makes the Item appear ingame.
	 *
	 * @param name is the registration name/ unlocalized name
	 */
	public ItemTest(String name) {
		setUnlocalizedName(name);
		setRegistryName(name);
		setCreativeTab(Wuxia.testtab);

		ItemInit.ITEMS.add(this);

	}

	/**
	 * Registers the model so it has an appearance.
	 */
	@Override
	public void registerModels() {
		Wuxia.proxy.registerItemRenderer(this, 0, "inventory");
	}

}
