package Wuxia.commands;

import java.util.List;

import com.google.common.collect.Lists;

import Wuxia.Energy.EnergyProvider;
import Wuxia.Energy.stun.IStun;
import Wuxia.Energy.stun.StundProvider;
import Wuxia.util.References;
import Wuxia.util.interfaces.IEnergy;
import net.minecraft.command.CommandBase;
import net.minecraft.command.CommandException;
import net.minecraft.command.ICommandSender;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextFormatting;

public class CommandSetAttribute extends CommandBase {

	private final List<String> aliases = Lists.newArrayList(References.MODID, "attributeSet", "attribute");

	@Override
	public String getName() {

		return "setAttributesOfTo";
	}

	@Override
	public String getUsage(ICommandSender sender) {
		return "setAttributesOfTo <attribute> <value>";
	}

	@Override
	public List<String> getAliases() {
		return aliases;
	}

	@Override
	public boolean checkPermission(MinecraftServer server, ICommandSender sender) {
		return super.checkPermission(server, sender);
	}

	@Override
	public int getRequiredPermissionLevel() {
		// TODO Auto-generated method stub
		return 4;
	}

	@Override
	public void execute(MinecraftServer server, ICommandSender sender, String[] args) throws CommandException {
		if (args.length < 1) {
			return;
		}
		String arg1 = args[0];
		String arg2 = args[1];
		IEnergy energy = sender.getCommandSenderEntity().getCapability(EnergyProvider.energyResource, null);
		IStun stun = sender.getCommandSenderEntity().getCapability(StundProvider.stunResource, null);
		switch (arg1) {
		case "Alive":
			try {
				int arg3 = Integer.parseInt(arg2);
				if (arg3 < -1 || arg3 > 1) {
					sender.sendMessage(new TextComponentString(
							TextFormatting.DARK_RED + "Invalid value, possible values:\n1\n0\n-1"));
					return;
				} else {
					energy.setAlive(arg3);
					sender.sendMessage(new TextComponentString("Successfully changed Alive to " + energy.getAlive()));
				}
			} catch (NumberFormatException e) {
				sender.sendMessage(
						new TextComponentString(TextFormatting.DARK_RED + "Invalid value, possible values:\n1\n0\n-1"));
				return;
			}
		case "Stun":
			try {
				int arg3 = Integer.parseInt(arg2);
				if (arg3 < -1) {
					sender.sendMessage(new TextComponentString(
							TextFormatting.DARK_RED + "Invalid value, please enter a positive value"));
					return;
				} else {
					if (arg3 == 0 || arg3 <= stun.getTickStunned()) {
						stun.setIsStunnned(false);
						stun.setTickStunned(0);
						stun.setstunDuration(0);
					}
					stun.setstunDuration(arg3);
					sender.sendMessage(
							new TextComponentString("Successfully changed Stun Duration to " + stun.getstunDuration()));
				}
			} catch (NumberFormatException e) {
				sender.sendMessage(new TextComponentString(
						TextFormatting.DARK_RED + "Invalid value, please enter a positive value, 0 to remove Stun"));
				return;
			}
			break;

		case "MaxEnergy":
			try {
				int arg3 = Integer.parseInt(arg2);
				if (arg3 < -1) {
					sender.sendMessage(new TextComponentString(
							TextFormatting.DARK_RED + "Invalid value, please enter a positive value"));
					return;
				} else {
					energy.setMaxEnergy(arg3);
					sender.sendMessage(
							new TextComponentString("Successfully changed Max Energy to " + energy.getMaxEnergy()));
				}
			} catch (NumberFormatException e) {
				sender.sendMessage(new TextComponentString(
						TextFormatting.DARK_RED + "Invalid value, please enter a positive value"));
				return;
			}
			break;
		case "Energy":
			try {
				int arg3 = Integer.parseInt(arg2);
				if (arg3 < -1) {

					sender.sendMessage(new TextComponentString(
							TextFormatting.DARK_RED + "Invalid value, please enter a positive value"));
					return;
				} else {
					if (arg3 > energy.getMaxEnergy()) {
						sender.sendMessage(new TextComponentString("The entered value is higher than your Max Energy,\n"
								+ " this will increase your Max Energy according to your latent talent,\n"
								+ " to set your Max Energy, use attribute MaxEnergy Value"));
						energy.increaseEnergy(arg3, (EntityPlayer) sender.getCommandSenderEntity());
						sender.sendMessage(
								new TextComponentString("Successfully increased Energy to " + energy.getEnergy()));
						return;
					}
					energy.setEnergy(arg3);
					sender.sendMessage(new TextComponentString("Successfully changed Energy to " + energy.getEnergy()));

				}
			} catch (NumberFormatException e) {
				sender.sendMessage(new TextComponentString(
						TextFormatting.DARK_RED + "Invalid value, please enter a positive value"));
				return;
			}
			break;
		case "LatentTalent":
			try {
				int arg3 = Integer.parseInt(arg2);
				if (arg3 < 1 || arg3 > 1000) {
					sender.sendMessage(new TextComponentString(
							TextFormatting.DARK_RED + "Invalid value, please enter a value between 1 and 1000\n"
									+ "(Latent Talent above 10 is not recommended)"));
					return;
				} else {
					energy.setLatentTalent(arg3);
					sender.sendMessage(new TextComponentString("Successfully changed Talent to "
							+ energy.getLatentTalent() + "(\nLatent Talent above 10 is not recommended)"));
				}
			} catch (NumberFormatException e) {
				sender.sendMessage(new TextComponentString(
						TextFormatting.DARK_RED + "Invalid value, please enter a positive value"));
				return;
			}
			break;
		case "Luck":
			try {
				int arg3 = Integer.parseInt(arg2);
				if (arg3 < 1 || arg3 > 1000) {
					sender.sendMessage(new TextComponentString(
							TextFormatting.DARK_RED + "Invalid value, please enter a value between 1 and 1000\n"
									+ "(Luck above 10 is not recommended)"));
					return;
				} else {
					energy.setLuck(arg3);

					sender.sendMessage(new TextComponentString("Successfully changed Luck to " + energy.getLuck()));
				}
			} catch (NumberFormatException e) {
				sender.sendMessage(new TextComponentString(
						TextFormatting.DARK_RED + "Invalid value, please enter a positive value between 1 and 1000\n"
								+ "(Luck above 10 is not recommended)"));
				return;
			}
			break;
		}
	}

}
