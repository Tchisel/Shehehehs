package Wuxia.tabs;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.ItemStack;
import Wuxia.init.ItemInit;

/**
 * Class for the In Game Test Tab
 * 
 * @author Tchisel
 *
 */
public class TestTab extends CreativeTabs {
	/**
	 * 
	 * @param label is the unlocalised name of the Tab
	 */
	public TestTab(String label) {
		super("label");
		this.setBackgroundImageName(label + ".png");
	}

	/**
	 * Gets the In Game visible Tab Icon
	 */
	@Override
	public ItemStack getTabIconItem() {
		return new ItemStack(ItemInit.TEST_ITEM);
	}

}
