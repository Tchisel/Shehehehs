package Wuxia.init;

import java.util.ArrayList;
import java.util.List;

import Wuxia.objects.items.ItemTest;
import Wuxia.objects.items.SpiritStone.SpiritStone;
import Wuxia.objects.items.SpiritStone.SpiritStoneUsed;
import Wuxia.objects.items.SpiritStone.StoneQuality;
import Wuxia.objects.items.armour.TestArmour;
import Wuxia.objects.items.pills.SmoothCultivationPill;
import Wuxia.objects.items.tools.AxeTest;
import Wuxia.objects.items.tools.HoeTest;
import Wuxia.objects.items.tools.PickaxeTest;
import Wuxia.objects.items.tools.ShovelTest;
import Wuxia.objects.items.tools.SpaceRing;
import Wuxia.objects.items.tools.SwordTest;
import Wuxia.objects.items.tools.TalentChecker;
import Wuxia.util.References;
import net.minecraft.init.SoundEvents;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.Item;
import net.minecraft.item.Item.ToolMaterial;
import net.minecraft.item.ItemArmor.ArmorMaterial;
import net.minecraftforge.common.util.EnumHelper;

// TODO: Auto-generated Javadoc
/**
 * Initialises all the items and materials.
 *
 * @author Tchisel
 */
public class ItemInit {

	public static final List<Item> ITEMS = new ArrayList<Item>();
	// NewItem-1
	public static final Item TEST_ITEM = new ItemTest("test_item");

	public static final ToolMaterial TEST_TOOLMATERIAL = EnumHelper.addToolMaterial("test_toolmaterial", 2, 250, 6.0f,
			2.0f, 14);

	public static final ArmorMaterial TEST_ARMORMATERIAL = EnumHelper.addArmorMaterial("test_armormaterial",
			References.MODID + ":test", 15, new int[] { 2, 5, 6, 2 }, 9, SoundEvents.ITEM_ARMOR_EQUIP_IRON, 0.0F);

	public static final Item TALENT_CHECKER = new TalentChecker("talent_checker");
	public static final Item SMOOTH_CULTIVATION_PILL = new SmoothCultivationPill("smooth_cultivation_pill");

	public static final Item SPACE_RING = new SpaceRing("space_ring");

	public static final Item TEST_HELMET = new TestArmour("test_helmet", TEST_ARMORMATERIAL, 1,
			EntityEquipmentSlot.HEAD);

	public static final Item TEST_CHESTPLATE = new TestArmour("test_chestplate", TEST_ARMORMATERIAL, 1,
			EntityEquipmentSlot.CHEST);

	public static final Item TEST_LEGS = new TestArmour("test_legs", TEST_ARMORMATERIAL, 2, EntityEquipmentSlot.LEGS);

	public static final Item TEST_BOOTS = new TestArmour("test_boots", TEST_ARMORMATERIAL, 1, EntityEquipmentSlot.FEET);

	public static final Item TEST_PICKAXE = new PickaxeTest("test_pickaxe", TEST_TOOLMATERIAL);

	public static final Item TEST_AXE = new AxeTest("test_axe", TEST_TOOLMATERIAL);

	public static final Item TEST_SHOVEL = new ShovelTest("test_shovel", TEST_TOOLMATERIAL);

	public static final Item TEST_HOE = new HoeTest("test_hoe", TEST_TOOLMATERIAL);

	public static final Item TEST_SWORD = new SwordTest("test_sword", TEST_TOOLMATERIAL);
	public static final Item SPRIT_STONE = new SpiritStone("spirit_stone0", StoneQuality.LOW);
	public static final Item SPRIT_STONE_USED = new SpiritStoneUsed("spirit_stone_used0", StoneQuality.LOW);
	public static final Item SPRIT_STONEMEDIUM = new SpiritStone("spirit_stone1", StoneQuality.MEDIUM);
	public static final Item SPRIT_STONE_USEDMEDIUM = new SpiritStoneUsed("spirit_stone_used1", StoneQuality.MEDIUM);
	public static final Item SPRIT_STONEHIGH = new SpiritStone("spirit_stone2", StoneQuality.HIGH);
	public static final Item SPRIT_STONE_USEDHIGH = new SpiritStoneUsed("spirit_stone_used2", StoneQuality.HIGH);
	public static final Item SPRIT_STONETOP = new SpiritStone("spirit_stone3", StoneQuality.TOP);
	public static final Item SPRIT_STONE_USEDTOP = new SpiritStoneUsed("spirit_stone_used3", StoneQuality.TOP);
	public static final Item FIREBALL = new Wuxia.objects.items.entities.FireBall("fireBall");

	public static Item getStone(StoneQuality quality, boolean used) {
		switch (quality) {
		case HIGH:
			return used ? SPRIT_STONE_USEDHIGH : SPRIT_STONEHIGH;
		case LOW:
			return used ? SPRIT_STONE_USED : SPRIT_STONE;
		case MEDIUM:
			return used ? SPRIT_STONE_USEDMEDIUM : SPRIT_STONEMEDIUM;
		case TOP:
			return used ? SPRIT_STONE_USEDTOP : SPRIT_STONETOP;
		default:
			return used ? SPRIT_STONE_USED : SPRIT_STONE;
		}

	}

}
