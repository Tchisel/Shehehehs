package Wuxia.init;

import Wuxia.generator.FlowerGenerator;
import Wuxia.generator.OreGenerator;
import Wuxia.generator.WorldGenCustomStructures;
import Wuxia.generator.generators.WorldGenTown;
import net.minecraftforge.fml.common.registry.GameRegistry;

// TODO: Auto-generated Javadoc
/**
 * registers the World generators.
 *
 * @author Tchisel
 */
public class WorldGen {

	/**
	 * Register world generators.
	 */
	public static void registerWorldGenerators() {
		GameRegistry.registerWorldGenerator(new FlowerGenerator(), 10);
		GameRegistry.registerWorldGenerator(new OreGenerator(), 1);
		GameRegistry.registerWorldGenerator(new WorldGenCustomStructures(), 0);
		GameRegistry.registerWorldGenerator(new WorldGenTown(), 0);
	}
}
