package Wuxia.init;

import Wuxia.Energy.EnergyProvider;
import Wuxia.Energy.ablities.AbilityProvider;
import Wuxia.Energy.stun.IStun;
import Wuxia.Energy.stun.StundProvider;
import Wuxia.util.References;
import Wuxia.util.interfaces.IAbility;
import Wuxia.util.interfaces.IEnergy;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityInject;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

// TODO: Auto-generated Javadoc
/**
 * The Class ModCapabilities.
 */
public class ModCapabilities {

	/** The capability energy. */
	@CapabilityInject(IEnergy.class)
	public static Capability<IEnergy> CAPABILITY_ENERGY = null;
	/** The Constant energyResource. */
	public static final ResourceLocation energyResource = new ResourceLocation(References.MODID, "energy");

	@CapabilityInject(IStun.class)
	public static Capability<IStun> CAPABILITY_STUN = null;
	/** The Constant stunResource. */
	public static final ResourceLocation stunResource = new ResourceLocation(References.MODID, "stun");

	@CapabilityInject(IAbility.class)
	public static Capability<IAbility> CAPABILITY_ABILTIY = null;
	/** The Constant stunResource. */
	public static final ResourceLocation abilityResource = new ResourceLocation(References.MODID, "ability");

	/**
	 * Attach capability.
	 *
	 * @param event the event
	 */
	@SubscribeEvent
	public void attachCapability(AttachCapabilitiesEvent<Entity> event) {
		if (!(event.getObject() instanceof EntityPlayer)) {
			return;
		}
		event.addCapability(energyResource, new EnergyProvider());
		event.addCapability(stunResource, new StundProvider());
		event.addCapability(abilityResource, new AbilityProvider());

	}
}
/**
 * The Class CapabilityEnergy.
 */
