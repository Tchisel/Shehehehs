package Wuxia.init;

import java.util.ArrayList;
import java.util.List;

import Wuxia.Wuxia;
import Wuxia.entites.TestEntity;
import Wuxia.entites.abilities.fire.FireBall;
import Wuxia.util.References;
import Wuxia.util.handlers.EntityHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.common.registry.EntityRegistry;

// TODO: Auto-generated Javadoc
/**
 * The Class EntityInit.
 */
public class EntityInit {

	/**
	 * Register entities.
	 */
	public static void registerEntities() {
		registerEntity("testEntity", TestEntity.class, References.TEST_ENTITY, 50, 4771461, 16318526);
		EntityHandler.registerProjectile("fireBall", References.FIREBALL, FireBall.class, ItemInit.FIREBALL);
	}

	/**
	 * Register entity.
	 *
	 * @param name   the name
	 * @param entity the entity
	 * @param id     the id
	 * @param range  the range
	 * @param color1 the color 1
	 * @param color2 the color 2
	 */
	public static void registerEntity(String name, Class<? extends Entity> entity, int id, int range, int color1,
			int color2) {
		EntityRegistry.registerModEntity(new ResourceLocation(References.MODID + ":" + name), entity, name, id,
				Wuxia.instance, range, 1, true, color1, color2);
	}

	/** The Constant ENTITIES. */
	public static final List<EntityMob> ENTITIES = new ArrayList<EntityMob>();
}
