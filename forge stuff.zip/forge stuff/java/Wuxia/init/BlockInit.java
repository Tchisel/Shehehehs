package Wuxia.init;

import java.util.ArrayList;
import java.util.List;

import Wuxia.Wuxia;
import Wuxia.objects.blocks.StatChecker;
import Wuxia.objects.blocks.TestBlock;
import Wuxia.objects.blocks.flowers.FlowerBase;
import Wuxia.objects.blocks.ores.SpiritStoneOre;
import Wuxia.objects.items.SpiritStone.StoneQuality;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;

// TODO: Auto-generated Javadoc
/**
 * Just initialises all the blocks.
 *
 * @author Tchisel
 */
public class BlockInit {

	/** The Constant BLOCKS. */
	public static final List<Block> BLOCKS = new ArrayList<Block>();

	/** The Constant TEST_BLOCK. */
	// New Block - 1
	public static final Block TEST_BLOCK = new TestBlock("test_block", Material.CLAY);

	/** The Constant TEST_FLOWER. */
	// flowers
	public static final Block TEST_FLOWER = new FlowerBase("test_flower", Wuxia.testtab);

	public static final Block STAT_CHECKER = new StatChecker("stat_checker", Material.GLASS);

	public static final Block SPIRIT_STONE_ORE_LOW = new SpiritStoneOre("spirit_stone_ore_low", StoneQuality.LOW,
			Material.GROUND);
	public static final Block SPIRIT_STONE_ORE_MEDIUM = new SpiritStoneOre("spirit_stone_ore_medium",
			StoneQuality.MEDIUM, Material.GROUND);
	public static final Block SPIRIT_STONE_ORE_HIGH = new SpiritStoneOre("spirit_stone_ore_high", StoneQuality.HIGH,
			Material.GROUND);
	public static final Block SPIRIT_STONE_ORE_TOP = new SpiritStoneOre("spirit_stone_ore_top", StoneQuality.TOP,
			Material.GROUND);

	public static Block getStoneOre(StoneQuality quality) {
		switch (quality) {
		case HIGH:
			return SPIRIT_STONE_ORE_HIGH;
		case LOW:
			return SPIRIT_STONE_ORE_LOW;
		case MEDIUM:
			return SPIRIT_STONE_ORE_MEDIUM;
		case TOP:
			return SPIRIT_STONE_ORE_TOP;
		default:
			return null;
		}
	}

}
