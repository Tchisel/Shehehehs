package Wuxia.proxy;

import org.lwjgl.input.Keyboard;

import Wuxia.Wuxia;
import Wuxia.Energy.CapabilityEnergy;
import Wuxia.Energy.Energy;
import Wuxia.Energy.ablities.Abilities;
import Wuxia.Energy.ablities.CapabilityAbility;
import Wuxia.Energy.stun.CapabilityStun;
import Wuxia.Energy.stun.IStun;
import Wuxia.Energy.stun.Stun;
import Wuxia.entites.RenderProjectile;
import Wuxia.entites.abilities.fire.FireBall;
import Wuxia.entites.models.ModelFireBall;
import Wuxia.init.ModCapabilities;
import Wuxia.util.handlers.EventHandler;
import Wuxia.util.handlers.GuiHandler;
import Wuxia.util.interfaces.IAbility;
import Wuxia.util.interfaces.IEnergy;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.item.Item;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.fml.common.network.NetworkRegistry;

// TODO: Auto-generated Javadoc
/**
 * Clientsided Events.
 *
 * @author Tchisel
 */
public class ClientProxy extends CommonProxy {


	public static KeyBinding[] keyBindings;

	

	
	/**
	 * Renders the Items for the Client/Player.
	 *
	 * @param item the item
	 * @param meta the meta
	 * @param id   the id
	 */
	@Override
	public void registerItemRenderer(Item item, int meta, String id) {
		ModelLoader.setCustomModelResourceLocation(item, meta,
				new ModelResourceLocation(item.getRegistryName(), "inventory"));
	}
	
	
	@Override
	public void render() {
		RenderingRegistry.registerEntityRenderingHandler(FireBall.class,
				new RenderProjectile(Minecraft.getMinecraft().getRenderManager(), new ModelFireBall(), 1.0f,
						new ResourceLocation("wx:textures/entity/sphere.png")));

		// RenderingRegistry.registerEntityRenderingHandler(FireBall.class,
		// new RenderProjectile(Minecraft.getMinecraft().getRenderManager(), 1.0f));

	}
}
