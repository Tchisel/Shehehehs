package Wuxia.proxy;

import org.lwjgl.input.Keyboard;

import Wuxia.Wuxia;
import Wuxia.Energy.CapabilityEnergy;
import Wuxia.Energy.Energy;
import Wuxia.Energy.ablities.Abilities;
import Wuxia.Energy.ablities.CapabilityAbility;
import Wuxia.Energy.stun.CapabilityStun;
import Wuxia.Energy.stun.IStun;
import Wuxia.Energy.stun.Stun;
import Wuxia.init.ModCapabilities;
import Wuxia.util.handlers.EventHandler;
import Wuxia.util.handlers.GuiHandler;
import Wuxia.util.interfaces.IAbility;
import Wuxia.util.interfaces.IEnergy;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.item.Item;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.network.NetworkRegistry;

// TODO: Auto-generated Javadoc
/**
 * Server Sided Events Currently not used as this is a Singleplayer Mod.
 *
 * @author Tchisel
 */
public class CommonProxy {


	/**
	 * Inits the.
	 */
	public void init() {
		CapabilityManager.INSTANCE.register(IEnergy.class, new CapabilityEnergy(), Energy::new);
		CapabilityManager.INSTANCE.register(IStun.class, new CapabilityStun(), Stun::new);
		CapabilityManager.INSTANCE.register(IAbility.class, new CapabilityAbility(), Abilities::new);
		MinecraftForge.EVENT_BUS.register(new ModCapabilities());
		MinecraftForge.EVENT_BUS.register(new EventHandler());
		NetworkRegistry.INSTANCE.registerGuiHandler(Wuxia.instance, new GuiHandler());
		ClientProxy.keyBindings = new KeyBinding[1]; 
		ClientProxy.keyBindings[0] = new KeyBinding("key.ability.desc", Keyboard.KEY_P, "key.wuxia.category");
		for (int i = 0; i < ClientProxy.keyBindings.length; ++i) 
		{
		    ClientRegistry.registerKeyBinding(ClientProxy.keyBindings[i]);
		}
	}

	/**
	 * Registers the Item Renderer. Only used via ClientProxy. Not Used
	 *
	 * @param item the item to be rendered
	 * @param meta always 0
	 * @param id   always inventory
	 */
	public void registerItemRenderer(Item item, int meta, String id) {

	}

	public void render() {

	}
}
