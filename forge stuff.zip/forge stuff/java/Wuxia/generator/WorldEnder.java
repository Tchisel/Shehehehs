package Wuxia.generator;

public class WorldEnder {

	private int y;
	public int[][] townChunks = new int[16][2];

	public WorldEnder(int[] xz, int y) {
		this.y = y;
		reserveChunks(xz[0], xz[1]);
	}

	private void reserveChunks(int x, int z) {
		int k = 0;
		for (int i = 0; i < 4; i++) {
			for (int j = 0; j < 4; j++) {
				townChunks[k][0] = x + j;
				townChunks[k][1] = z + i;
				k++;
			}
		}
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public int getReservedChunk(int[] xz) {
		for (int i = 0; i < 16; i++) {
			if (townChunks[i][0] == xz[0] && townChunks[i][1] == xz[1]) {
				return i;
			}
		}
		return -1;
	}
}
