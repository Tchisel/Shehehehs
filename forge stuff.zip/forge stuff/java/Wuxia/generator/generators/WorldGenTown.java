package Wuxia.generator.generators;

import java.util.ArrayList;
import java.util.Random;

import Wuxia.generator.WorldEnder;
import Wuxia.generator.generators.walledTown.WorldGenTownStructure;
import net.minecraft.block.Block;
import net.minecraft.init.Biomes;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldType;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.gen.IChunkGenerator;
import net.minecraftforge.fml.common.IWorldGenerator;
import scala.actors.threadpool.Arrays;

public class WorldGenTown implements IWorldGenerator {

	public static final WorldGenTownStructure x0y0 = new WorldGenTownStructure("walledTown/walledTown0,0");
	public static final WorldGenTownStructure x0y1 = new WorldGenTownStructure("walledTown/walledTown0,1");
	public static final WorldGenTownStructure x0y2 = new WorldGenTownStructure("walledTown/walledTown0,2");
	public static final WorldGenTownStructure x0y3 = new WorldGenTownStructure("walledTown/walledTown0,3");
	public static final WorldGenTownStructure x1y0 = new WorldGenTownStructure("walledTown/walledTown1,0");
	public static final WorldGenTownStructure x1y1 = new WorldGenTownStructure("walledTown/walledTown1,1");
	public static final WorldGenTownStructure x1y2 = new WorldGenTownStructure("walledTown/walledTown1,2");
	public static final WorldGenTownStructure x1y3 = new WorldGenTownStructure("walledTown/walledTown1,3");
	public static final WorldGenTownStructure x2y0 = new WorldGenTownStructure("walledTown/walledTown2,0");
	public static final WorldGenTownStructure x2y1 = new WorldGenTownStructure("walledTown/walledTown2,1");
	public static final WorldGenTownStructure x2y2 = new WorldGenTownStructure("walledTown/walledTown2,2");
	public static final WorldGenTownStructure x2y3 = new WorldGenTownStructure("walledTown/walledTown2,3");
	public static final WorldGenTownStructure x3y0 = new WorldGenTownStructure("walledTown/walledTown3,0");
	public static final WorldGenTownStructure x3y1 = new WorldGenTownStructure("walledTown/walledTown3,1");
	public static final WorldGenTownStructure x3y2 = new WorldGenTownStructure("walledTown/walledTown3,2");
	public static final WorldGenTownStructure x3y3 = new WorldGenTownStructure("walledTown/walledTown3,3");

	public static final ArrayList<ArrayList<int[]>> reservedLists = new ArrayList<ArrayList<int[]>>();
	public static final ArrayList<int[]> chunksWithBiome = new ArrayList<int[]>();
	public static final ArrayList<WorldEnder> reservedChunksEnder = new ArrayList<WorldEnder>();
	public boolean StartUp = true;

	public WorldGenTown() {
		if (StartUp) {
			for (int i = 0; i < 10; i++)
				reservedLists.add(new ArrayList<int[]>());
			fillList();
		}
	}

	@Override
	public void generate(Random random, int chunkX, int chunkZ, World world, IChunkGenerator chunkGenerator,
			IChunkProvider chunkProvider) {
		switch (world.provider.getDimension()) {
		case 0:/*
				 * if (StartUp) { for (int i = -100; i < 101; i++) { for (int j = -100; j < 101;
				 * j++) { chunkGenerator.generateChunk(i, j); if (world.getBiome(new BlockPos(i
				 * * 16, 50, j * 16)) == BiomeInit.TOWNBIOME) { chunksWithBiome.add(new int[] {
				 * i, j }); } } } for (int[] intArray : chunksWithBiome) { int k = 0;
				 * 
				 * for (int i = -3; i < 3; i++) { for (int j = -3; j < 3; j++) { if
				 * (world.getBiome( new BlockPos(intArray[0] + i, 50, intArray[1] + j)) ==
				 * BiomeInit.TOWNBIOME) { k++; } else { break; }
				 * 
				 * } } if (k == 25) { TownBiome biome = (TownBiome) world.getBiome(new
				 * BlockPos(intArray[0], 50, intArray[1])); if (biome.hasCity) {
				 * 
				 * } else { ArrayList lister = new ArrayList<int[]>(); for (int i = -3; i < 3;
				 * i++) { for (int j = -3; j < 3; j++) { lister.add(intArray); } }
				 * reservedLists.add(lister); biome = (TownBiome) world.getBiome(new
				 * BlockPos(intArray[0], 50, intArray[1])); biome.hasCity = true; } }
				 * 
				 * }
				 * 
				 * StartUp = !StartUp; }
				 */
			/*
			 * if (reservedChunks(new int[] { chunkX, chunkZ })) { IChunkGenerator x = new
			 * ChunkGeneratort(world, world.getSeed(), true, null); x.generateChunk(chunkX,
			 * chunkZ); }
			 */

			int y = 50;
			int[] xz = { chunkX, chunkZ };

			if (reservedChunks(xz)) {
				int chunk = -1;
				for (WorldEnder ender : reservedChunksEnder) {
					int reserver = ender.getReservedChunk(xz);
					if (reserver != -1) {
						y = ender.getY();
						if (y == 10) {
							y = getLowestPoint(ender.townChunks[reserver][0], ender.townChunks[reserver][1], world);
							ender.setY(y);
						}
						chunk = ender.getReservedChunk(xz);
						break;
					}
				}
				BlockPos pos = new BlockPos(chunkX * 16, y, chunkZ * 16);

				if (chunk != -1) {
					if (isOk(chunkX, chunkZ, world)) {
						switch (chunk) {
						case 0:
							x0y0.generate(world, random, pos);
							break;
						case 1:
							x0y1.generate(world, random, pos);
							break;
						case 2:
							x0y2.generate(world, random, pos);
							break;
						case 3:
							x0y3.generate(world, random, pos);
							setSand(world, pos, 5, 0);
							break;
						case 4:
							x1y0.generate(world, random, pos);
							break;
						case 5:
							x1y1.generate(world, random, pos);
							break;
						case 6:
							x1y2.generate(world, random, pos);
							break;
						case 7:
							x1y3.generate(world, random, pos);
							setSand(world, pos, 5, 0);
							break;
						case 8:
							x2y0.generate(world, random, pos);
							break;
						case 9:
							x2y1.generate(world, random, pos);
							break;
						case 10:
							x2y2.generate(world, random, pos);
							break;
						case 11:
							x2y3.generate(world, random, pos);
							setSand(world, pos, 5, 0);
							break;
						case 12:
							x3y0.generate(world, random, pos);
							setSand(world, pos, 0, 4);
							break;
						case 13:
							x3y1.generate(world, random, pos);
							setSand(world, pos, 0, 4);
							break;
						case 14:
							x3y2.generate(world, random, pos);
							setSand(world, pos, 0, 4);
							break;
						case 15:
							x3y3.generate(world, random, pos);
							setSand(world, pos, 5, 0);
							setSand(world, pos, 0, 4);
							break;
						}
					}
				}
			} else {

			}

		}
	}

	void setSand(World world, BlockPos pos, int x, int y) {
		for (int j = y; j < 16; j++) {
			for (int i = x; i < 16; i++) {
				world.setBlockState(new BlockPos(pos.getX() + i, pos.getY() + 1, pos.getZ() + j),
						Blocks.SAND.getDefaultState());
			}

		}
	}

	public static boolean reservedChunks(int[] xz) {
		for (ArrayList<int[]> liste : reservedLists) {
			for (int[] iArray : liste) {
				if (Arrays.equals(xz, iArray)) {
					return true;
				}
			}
		}
		return false;
	}

	private void fillList() {
		int list = -5;
		for (ArrayList<int[]> liste : reservedLists) {
			for (int i = list; i < (list + 1); i++) {
				for (int j = list; j < (list + 1); j++) {
					fillLister(i, j, liste);
				}
			}
			list++;
		}
	}

	private void fillLister(int i, int j, ArrayList<int[]> list) {
		WorldEnder adder = new WorldEnder(new int[] { i * 100, j * 100 }, 10);
		reservedChunksEnder.add(adder);
		for (int k = 0; k < 16; k++) {
			list.add(adder.townChunks[k]);
		}
	}

	public boolean isOk(int chunkX, int chunkZ, World world) {
		BlockPos pos = new BlockPos(chunkX * 16, 70, chunkZ * 16);
		if (world.getBiome(pos) != Biomes.OCEAN || world.getBiome(pos) != Biomes.DEEP_OCEAN) {
			return true;
		}
		return false;
	}

	private static int getLowestPoint(int cX, int cZ, World world) {
		int[][] height = new int[16][16];
		int lowestX = 0;
		int lowestZ = 0;
		int low = world.getWorldType() == WorldType.FLAT ? 4 : 200;
		for (int i = 0; i < 16; i++) {
			for (int j = 0; j < 16; j++) {
				height[i][j] = getGroundFromAbove(world, cX * 16 + i, cZ * 16 + j);
				lowestX = height[i][j] < low && height[i][j] >= 60 ? i : lowestX;
				lowestZ = height[i][j] < low && height[i][j] >= 60 ? j : lowestZ;
				low = height[i][j] < low && height[i][j] >= 60 ? height[i][j] : low;
			}
		}
		return low;
	}

	public static int getGroundFromAbove(World world, int x, int z) {
		int y = world.getHeight();
		boolean foundGround = false;
		while (!foundGround && y-- >= 0) {
			final Block blockAt = world.getBlockState(new BlockPos(x, y, z)).getBlock();
			// "ground" for our bush is grass or dirt
			foundGround = blockAt == Blocks.DIRT || blockAt == Blocks.GRASS || blockAt == Blocks.SAND
					|| blockAt == Blocks.GRAVEL
					|| (blockAt != Blocks.AIR && blockAt != Blocks.LEAVES && blockAt != Blocks.LOG);
		}

		return y;
	}
}
