package Wuxia.generator.generators.walledTown;

import Wuxia.entites.TestEntity;
import net.minecraft.init.Blocks;
import net.minecraft.world.biome.Biome;

public class TownBiome extends Biome {
	public boolean hasCity = false;

	public TownBiome() {
		super(new BiomeProperties("townBiome").setHeightVariation(0.0001f).setRainDisabled().setWaterColor(16777215));

		topBlock = Blocks.DIRT.getDefaultState();
		fillerBlock = Blocks.DIRT.getDefaultState();

		this.modSpawnableLists.clear();
		this.spawnableCaveCreatureList.clear();
		this.spawnableCreatureList.clear();
		this.spawnableCreatureList.add(new SpawnListEntry(TestEntity.class, 0, 3, 10));
	}

}