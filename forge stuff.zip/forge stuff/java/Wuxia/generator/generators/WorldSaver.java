package Wuxia.generator.generators;

import net.minecraft.util.math.BlockPos;

public class WorldSaver {
	public int[] e;
	public BlockPos b;
	public int[][] a;

	public WorldSaver(int[] c, BlockPos d) {
		e = c;
		b = d;
	}

	public WorldSaver(int[][] c, BlockPos d) {
		a = c;
		b = d;
	}

}
