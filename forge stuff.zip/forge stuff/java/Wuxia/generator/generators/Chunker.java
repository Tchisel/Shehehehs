package Wuxia.generator.generators;

public class Chunker {
	int x;
	int y;

	public Chunker(int cx, int cy) {
		x = cx;
		y = cy;
	}
}
