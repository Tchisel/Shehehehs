package Wuxia.generator;

import java.util.Random;

import Wuxia.init.BlockInit;
import Wuxia.init.ItemInit;
import Wuxia.objects.blocks.flowers.FlowerBase;
import net.minecraft.block.BlockBush;
import net.minecraft.init.Biomes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.gen.IChunkGenerator;
import net.minecraft.world.gen.feature.WorldGenerator;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.IWorldGenerator;

// TODO: Auto-generated Javadoc
/**
 * The Class FlowerGenerator.
 */
public class FlowerGenerator extends WorldGenerator implements IWorldGenerator {

	/**
	 * Generate.
	 *
	 * @param worldIn the world in
	 * @param rand the rand
	 * @param position the position
	 * @return true, if successful
	 */
	@Override
	public boolean generate(World worldIn, Random rand, BlockPos position) {

		BlockBush test_flower = (BlockBush) BlockInit.TEST_FLOWER;
		for (int i = 0; i < 64; i++) {
			BlockPos blockpos = position.add(rand.nextInt(8) - rand.nextInt(8), rand.nextInt(4) - rand.nextInt(4),
					rand.nextInt(8) - rand.nextInt(8));
			// TestBiome(worldIn, blockpos);
			if (worldIn.isAirBlock(blockpos) && (blockpos.getY() < 255)
					&& test_flower.canBlockStay(worldIn, blockpos, test_flower.getDefaultState())) {
				worldIn.setBlockState(blockpos, test_flower.getDefaultState(), 2);
			}
		}

		return true;
	}

	/**
	 * Generate.
	 *
	 * @param rand the rand
	 * @param chunkX the chunk X
	 * @param chunkZ the chunk Z
	 * @param worldIn the world in
	 * @param chunkGenerator the chunk generator
	 * @param chunkProvider the chunk provider
	 */
	@Override
	public void generate(Random rand, int chunkX, int chunkZ, World worldIn, IChunkGenerator chunkGenerator,
			IChunkProvider chunkProvider) {

	}

	/*
	 * @Test public void TestBiome(World worldIn, BlockPos blockpos) {
	 * assertEquals(Biomes.PLAINS, worldIn.getBiome(blockpos)); }
	 */
}
