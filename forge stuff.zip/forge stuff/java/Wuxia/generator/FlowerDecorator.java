package Wuxia.generator;

import java.util.Random;

import Wuxia.init.BlockInit;
import net.minecraft.block.BlockBush;
import net.minecraft.block.BlockFlower;
import net.minecraft.init.Biomes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.BiomeDecorator;
import net.minecraft.world.biome.BiomePlains;
import net.minecraft.world.gen.feature.WorldGenBigMushroom;
import net.minecraft.world.gen.feature.WorldGenBush;
import net.minecraftforge.event.terraingen.TerrainGen;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.terraingen.DecorateBiomeEvent;

// TODO: Auto-generated Javadoc
/**
 * Don't know if it has to be an EventBusSubscriber, even tho it makes sense As
 * a BiomeDecorator, this class is used to Spawn my Custom Plants in the World.
 *
 * @author Tchisel
 */
@EventBusSubscriber
public class FlowerDecorator extends BiomeDecorator {
	
	/** The flower gen. */
	protected FlowerGenerator flowerGen;

	/**
	 * Adds the Flower Decorator to the Event Bus when called during the
	 * FMLInitializationEvent in class Wuxia.
	 */
	public FlowerDecorator() {
		super();
		MinecraftForge.EVENT_BUS.register(this);
	}

	/**
	 * Calls the function generateFlowers when the Biome that calls the
	 * DecorateBiomeEvent.Pre event is a Plains
	 * 
	 * @param event is being called when a new Biome is generated
	 */
	@SubscribeEvent
	public void decorate(DecorateBiomeEvent.Pre event) {

		World world = event.getWorld();
		Biome biome = world.getBiomeForCoordsBody(event.getPos());
		Random rand = event.getRand();
		// System.out.print(biome.getBiomeName());
		if (biome == Biomes.PLAINS) {
			generateFlowers(world, biome, rand, event.getPos());
		}
	}

	/**
	 * Places the flowers in the world. There is a random chance of a flower
	 * spawning every block
	 * 
	 * @param worldIn  the world (eg. Nether, Overworld, End)
	 * @param biomeIn  the Biome that is being loaded
	 * @param random   a random int
	 * @param chunkPos the x and y coordinates of the chunk being loaded
	 */
	private void generateFlowers(World worldIn, Biome biomeIn, Random random, BlockPos chunkPos) {
		if (TerrainGen.decorate(worldIn, random, chunkPos, DecorateBiomeEvent.Decorate.EventType.FLOWERS))
			for (int numFlowersGenerated = 0; numFlowersGenerated < 2; ++numFlowersGenerated) {
				int flowerX = random.nextInt(16) + 8;
				int flowerZ = random.nextInt(16) + 8;
				int yRange = worldIn.getHeight(chunkPos.add(flowerX, 0, flowerZ)).getY() + 32;

				flowerGen = new FlowerGenerator();

				if (yRange > 0) {
					int flowerY = random.nextInt(yRange);
					BlockPos flowerBlockPos = chunkPos.add(flowerX, flowerY, flowerZ);
					flowerGen.generate(worldIn, random, flowerBlockPos);
				}
			}
	}

}
