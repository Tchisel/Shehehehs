package Wuxia.generator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

import Wuxia.generator.generators.Chunker;
import Wuxia.generator.generators.WorldGenStructure;
import Wuxia.generator.generators.WorldSaver;
import net.minecraft.block.Block;
import net.minecraft.init.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldType;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.gen.IChunkGenerator;
import net.minecraft.world.gen.feature.WorldGenerator;
import net.minecraftforge.fml.common.IWorldGenerator;

// TODO: Auto-generated Javadoc
/**
 * The Class WorldGenCustomStructures.
 */
public class WorldGenCustomStructures implements IWorldGenerator {
	public int[][] arr3;
	/** The Constant HOUSE. */
	public static final WorldGenStructure HOUSE = new WorldGenStructure("city");

	/** The last generatet. */
	public int lastGeneratet = 0;

	/** The last chunkx. */
	public int lastChunkx;

	/** The last chunky. */
	public int lastChunky;

	/** The generate next. */
	public boolean generateNext = false;

	/**
	 * Gets the ground from above.
	 *
	 * @param world the world
	 * @param x     the x
	 * @param z     the z
	 * @return the ground from above
	 */
	public static int getGroundFromAbove(World world, int x, int z) {
		int y = world.getHeight();
		boolean foundGround = false;
		while (!foundGround && y-- >= 0) {
			final Block blockAt = world.getBlockState(new BlockPos(x, y, z)).getBlock();
			// "ground" for our bush is grass or dirt
			foundGround = blockAt == Blocks.DIRT || blockAt == Blocks.GRASS || blockAt == Blocks.SAND
					|| blockAt == Blocks.GRAVEL || blockAt != Blocks.AIR;
		}

		return y;
	}

	/**
	 * Generate.
	 *
	 * @param random         the random
	 * @param chunkX         the chunk X
	 * @param chunkZ         the chunk Z
	 * @param world          the world
	 * @param chunkGenerator the chunk generator
	 * @param chunkProvider  the chunk provider
	 */
	ArrayList<Chunker> chunksToBeLoadedTo = new ArrayList<Chunker>();

	private boolean contains(int cX, int cY) {
		for (int i = -1; i <= 1; i++) {
			for (int j = -1; j <= 1; j++) {
				if (chunksToBeLoadedTo.contains(new Chunker(cX + i, cY + j))) {
					return true;
				}
			}
		}
		return false;

	}

	@Override
	public void generate(Random random, int chunkX, int chunkZ, World world, IChunkGenerator chunkGenerator,
			IChunkProvider chunkProvider) {
		switch (world.provider.getDimension()) {
		case 1:
			break;
		case 0:
			//
			// generateStructure(HOUSE, 0, world, random, chunkX, chunkZ, 150,
			// BiomePlains.class);
			// if (world.getBiome(new BlockPos(chunkX * 16, 1, chunkZ * 16)).getClass() ==
			// BiomePlains.class) {
			// int chunkXModulo = (int) (chunkX % 100.0);
			// if ((chunkX % 100.0 == 0 && chunkZ % 100.0 == 0 && (chunkZ != 0 && chunkZ !=
			// 0))) {
			// if (world.getWorldType() == WorldType.FLAT) {
			// final int y = 4;
			// final BlockPos pos = new BlockPos(chunkX * 16, y, chunkZ * 16);
			// HOUSE.generate(world, random, pos);
			// generateNext = false;
			// }
			// if (random.nextInt(2) == 0/* && !contains(chunkX, chunkZ) */) {
			/*
			 * int lowY = 60; ArrayList<WorldSaver> thanite = new ArrayList<WorldSaver>();
			 * for (int i = -1; i <= 1; i++) { for (int j = -1; j <= 1; j++) { WorldSaver c
			 * = getLowestPoint(chunkX, chunkZ, world); int y = c.b.getY(); thanite.add(c);
			 * if (y <= lowY) { lowY = y; } } }
			 */

			// System.out.print(chunkX * 16 + "/" + chunkZ * 16);
			// generateCity(world, random, chunkX, chunkZ);
			// for (int i = -5; i <= 5; i += 5) {
			// for (int j = -5; j <= 5; j += 5) {/*
			/*
			 * flattenGround(chunkX + i, chunkZ + j, world, lowY, thanite);
			 */
			// chunksToBeLoadedTo.add(new Chunker(chunkX + i, chunkZ + j));
			// switch (random.nextInt(2)) {
			// case 0:
			// generateStore(world, random, chunkX/* + i */, chunkZ /* + j */);
			// break;
			// default:
			// generateHouse(world, random, chunkX /* + i */, chunkZ /* + j */);
			// break;
			// }
			// }
			// }
			// }
			// }

			// }

			/*
			 * { if (random.nextInt(100) == 0 || generateNext) { lastChunky = chunkZ - 2;
			 * lastChunkx = chunkX;
			 * 
			 * generateHous4(world, random, lastChunkx, lastChunky); generateHous3(world,
			 * random, chunkX, chunkZ);
			 * 
			 * } }
			 */
			break;
		case -1:
			break;
		default:
			break;

		}

	}

	/*
	 * private static void flattenGround(int cX, int cZ, World world, int y,
	 * ArrayList<WorldSaver> thanos) { int m = 0; for (int i = -1; i <= 1; i++) {
	 * for (int j = -1; j <= 1; j++) { for (int k = 0; k < 16; k++) { for (int l =
	 * 0; l < 16; l++) { for (int n = 120; n > y; n--) {// thanos.get(m).a[k][l]
	 * BlockPos setToAir = new BlockPos(k + (cX + i) * 16, n, l + (cZ + j) * 16);
	 * world.setBlockToAir(setToAir); } } } m++; } } }
	 * 
	 * /* int lowestY = 256; WorldSaver thanos = getLowestPoint(cX, cZ, world);
	 * 
	 * lowestY = thanos.b.getY(); for (int i = 0; i < 16; i++) { for (int j = 0; j <
	 * 16; j++) { for (int k = thanos.a[i][j]; k > lowestY; k--) { BlockPos setToAir
	 * = new BlockPos(i + cX * 16, k, j + cZ * 16); world.setBlockToAir(setToAir); }
	 * }
	 * 
	 * }
	 */

	private static WorldSaver getLowestPoint(int cX, int cZ, World world) {
		int[][] height = new int[16][16];
		int lowestX = 0;
		int lowestZ = 0;
		int low = 256;
		for (int i = 0; i < 16; i++) {
			for (int j = 0; j < 16; j++) {
				height[i][j] = getGroundFromAbove(world, cX * 16 + i, cZ * 16 + j);
				lowestX = height[i][j] < low && height[i][j] >= 60 ? i : lowestX;
				lowestZ = height[i][j] < low && height[i][j] >= 60 ? j : lowestZ;
				low = height[i][j] < low && height[i][j] >= 60 ? height[i][j] : low;
			}
		}
		return new WorldSaver(height, new BlockPos(lowestX, low, lowestZ));
	}

	/**
	 * Generate hous 3.
	 *
	 * @param world  the world
	 * @param rand   the rand
	 * @param chunkX the chunk X
	 * @param chunkZ the chunk Z
	 */
	private void generateHouse(World world, Random rand, int chunkX, int chunkZ) {
		final int y = getGroundFromAbove(world, chunkX * 16, chunkZ * 16) + 50;
		final BlockPos pos = new BlockPos(chunkX * 16, y + 1, chunkZ * 16);
		HOUSE.generate(world, rand, pos);
		generateNext = false;
	}

	private void generateCity(World world, Random rand, int chunkX, int chunkZ) {
		final int y = getLowestPoint(chunkX * 16, chunkZ * 16, world).b.getY();
		final BlockPos pos = new BlockPos(chunkX * 16, y - 14, chunkZ * 16);
		HOUSE.generate(world, rand, pos);
		generateNext = false;
	}

	/**
	 * Generate hous 4.
	 *
	 * @param world  the world
	 * @param rand   the rand
	 * @param chunkX the chunk X
	 * @param chunkZ the chunk Z
	 */
	private void generateStore(World world, Random rand, int chunkX, int chunkZ) {
		final int y = getGroundFromAbove(world, chunkX * 16, chunkZ * 16) + 50;
		final BlockPos pos = new BlockPos(chunkX * 16, y + 1, chunkZ * 16);

		HOUSE.generate(world, rand, pos);
		lastGeneratet = 1;
		generateNext = true;
	}

	/**
	 * Generate structure.
	 *
	 * @param generator the generator
	 * @param stType    the st type
	 * @param world     the world
	 * @param random    the random
	 * @param chunkX    the chunk X
	 * @param chunkZ    the chunk Z
	 * @param chance    the chance
	 * @param classes   the classes
	 */
	private void generateStructure(WorldGenerator generator, int stType, World world, Random random, int chunkX,
			int chunkZ, int chance, Class<?>... classes) {
		final ArrayList<Class<?>> classesList = new ArrayList<Class<?>>(Arrays.asList(classes));

		final int x = (chunkX * 16) + random.nextInt(15);
		final int z = (chunkZ * 16) + random.nextInt(15);
		int y;

		y = getGroundFromAbove(world, x, z);

		final BlockPos pos = new BlockPos(x, y, z);
		final Class<?> biome = world.provider.getBiomeForCoords(pos).getClass();
		if (world.getWorldType() != WorldType.FLAT) {
			if (classesList.contains(biome)) {
				if (random.nextInt(chance) == 0) {
					generator.generate(world, random, pos);

				}
			}
		}

	}

}
