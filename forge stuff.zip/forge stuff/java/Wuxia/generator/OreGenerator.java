package Wuxia.generator;

import java.util.ArrayList;
import java.util.Random;
import java.util.ServiceLoader;

import Wuxia.init.BlockInit;
import Wuxia.objects.blocks.BlockOreole;
import net.minecraft.block.Block;
import net.minecraft.block.state.pattern.BlockMatcher;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.chunk.IChunkProvider;
import net.minecraft.world.gen.IChunkGenerator;
import net.minecraft.world.gen.feature.WorldGenMinable;
import net.minecraft.world.gen.feature.WorldGenerator;
import net.minecraftforge.fml.common.IWorldGenerator;

// TODO: Auto-generated Javadoc
/**
 * The Class OreGenerator.
 */
public class OreGenerator implements IWorldGenerator {

	/** The ores. */
	private ArrayList<BlockOreole> ores = new ArrayList<>();

	/** The gen. */
	public WorldGenerator gen;

	/**
	 * Generate.
	 *
	 * @param random         the random
	 * @param chunkX         the chunk X
	 * @param chunkZ         the chunk Z
	 * @param world          the world
	 * @param chunkGenerator the chunk generator
	 * @param chunkProvider  the chunk provider
	 */
	@Override
	public void generate(Random random, int chunkX, int chunkZ, World world, IChunkGenerator chunkGenerator,
			IChunkProvider chunkProvider) {
		for (BlockOreole ore : ores) {
			for (int i = 0; i < ore.CHANCE(); i++) {
				BlockPos pos = getBlockPos(chunkX, chunkZ, random, ore, world);
				if (pos.getY() != -1)

					if (i == 0 || random.nextInt((ore.MAXHEIGHT() - ore.MINHEIGHT()) / ore.CHANCE()) <= ore.CHANCE()) {
						gen = new WorldGenMinable(((Block) ore).getDefaultState(), ore.CHANCE() * 4,
								BlockMatcher.forBlock(Block.getBlockById(ore.GENERATESIN())));
						gen.generate(world, random, pos);
					}
			}
		}
	}

	/**
	 * Instantiates a new ore generator.
	 */
	public OreGenerator() {
		ServiceLoader<BlockOreole> loader = ServiceLoader.load(BlockOreole.class);
		for (BlockOreole implClass : loader) {
			ores.add(implClass);
		}

		ores.add((BlockOreole) BlockInit.TEST_BLOCK);
	}

	/**
	 * Gets the y.
	 *
	 * @param random      the random
	 * @param MaxHeight   the max height
	 * @param MinHeight   the min height
	 * @param world       the world
	 * @param x           the x
	 * @param z           the z
	 * @param generatesIn the generates in
	 * @return the y
	 */
	public int getY(Random random, int MaxHeight, int MinHeight, World world, int x, int z, int generatesIn) {
		int y = random.nextInt(MaxHeight >= MinHeight ? MaxHeight - MinHeight : -1);
		if (Block.isEqualTo(world.getBlockState(new BlockPos(x, y, z)).getBlock(), Block.getBlockById(generatesIn))) {
			return y;
		}
		return -1;
	}

	/**
	 * Gets the block pos.
	 *
	 * @param chunkX the chunk X
	 * @param chunkZ the chunk Z
	 * @param random the random
	 * @param ore    the ore
	 * @param world  the world
	 * @return the block pos
	 */
	private BlockPos getBlockPos(int chunkX, int chunkZ, Random random, BlockOreole ore, World world) {
		int x = chunkX * 16 + random.nextInt(16);
		int z = chunkZ * 16 + random.nextInt(16);
		int y = getY(random, ore.MAXHEIGHT(), ore.MINHEIGHT(), world, x, z, ore.GENERATESIN());
		return new BlockPos(x, y, z);
	}
}
