package Wuxia.gui;

import java.text.DecimalFormat;

import Wuxia.Energy.EnergyProvider;
import Wuxia.util.interfaces.IEnergy;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;

public class HealthGui extends Gui {
	private static final ResourceLocation guiTexture = new ResourceLocation("wx:textures/gui/healthbar.png");
	private float Health;
	private float MaxHealth;
	private EntityPlayer player;
	private int Energy;
	private int MaxEnergy;

	public HealthGui(EntityPlayer player) {
		MaxHealth = player.getMaxHealth();
		Health = player.getHealth();
		IEnergy energy = player.getCapability(EnergyProvider.energyResource, null);
		Energy = energy.getEnergy();
		MaxEnergy = energy.getMaxEnergy();
		this.player = player;

	}

	public void renderOverlayBar() {
		Minecraft.getMinecraft().getTextureManager().bindTexture(guiTexture);
		drawTexturedModalRect(10, 10, 0, 0, 130, 14);
		drawTexturedModalRect(10, 25, 0, 14, 130, 14);
		int health = (int) (128 / MaxHealth * Health);
		double energ = (10000000 / MaxEnergy * Energy);
		int eenergy = (int) (128 * (energ / 10000000));
		if (MaxEnergy == Energy)
			eenergy = 128;
		drawTexturedModalRect(11, 11, 0, 28, health, 12);
		drawTexturedModalRect(11, 26, 0, 40, eenergy, 12);

	}

	public void renderOverlayText() {
		Minecraft.getMinecraft().fontRenderer.drawString(getHealth(Health) + " / " + getHealth((this.MaxHealth)), 20,
				15, 0xffffff);
		Minecraft.getMinecraft().fontRenderer.drawString(Integer.toString(Energy) + " / " + Integer.toString(MaxEnergy),
				20, 30, 0xffffff);
	}

	private String getHealth(Float health) {
		DecimalFormat df = new DecimalFormat("#########.##");
		return df.format(health);
	}
}
