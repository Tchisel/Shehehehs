package Wuxia.gui;

import java.io.IOException;

import Wuxia.Energy.EnergyProvider;
import Wuxia.util.interfaces.IEnergy;
import Wuxia.util.interfaces.Stat;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.ResourceLocation;

public class StatGui extends GuiScreen {
	private int STRENGTH;
	private int SPEED;
	private int VITALITY;
	private int DIVINESENSE;
	private int SPIRIT;
	private String STAGE;
	private int ENERGY;
	private int LATENTTALENT;
	private static final ResourceLocation guiTexture = new ResourceLocation("wx:textures/gui/stat_checker.png");

	public StatGui(EntityPlayer player) {
		IEnergy energy = player.getCapability(EnergyProvider.energyResource, null);
		STRENGTH = energy.getStat(Stat.STRENTGH);
		SPEED = energy.getStat(Stat.SPEED);
		VITALITY = energy.getStat(Stat.VITALITY);
		DIVINESENSE = energy.getStat(Stat.DIVINESENSE);
		SPIRIT = energy.getStat(Stat.SPIRIT);
		STAGE = energy.getStage().toString();
		ENERGY = energy.getMaxEnergy();
		LATENTTALENT = energy.getLatentTalent();
	}

	@Override
	public void drawScreen(int mouseX, int mouseY, float partialTicks) {
		mc.getTextureManager().bindTexture(guiTexture);
		drawTexturedModalRect(0, 0, 0, 0, 256, 256);
		drawString(fontRenderer, "Strength = " + Integer.toString(STRENGTH), 100, 40, 0x463a4f);
		drawString(fontRenderer, "Vitality = " + Integer.toString(VITALITY), 100, 60, 0x463a4f);
		drawString(fontRenderer, "Speed = " + Integer.toString(SPEED), 100, 80, 0x463a4f);
		drawString(fontRenderer, "Divine Sense = " + Integer.toString(DIVINESENSE), 100, 180, 0x463a4f);
		drawString(fontRenderer, "Spirit = " + Integer.toString(SPIRIT), 100, 100, 0x463a4f);
		drawString(fontRenderer, "Stage = " + (STAGE), 100, 120, 0x463a4f);
		drawString(fontRenderer, "Energy = " + Integer.toString(ENERGY), 100, 140, 0x463a4f);
		drawString(fontRenderer, "Talent = " + Integer.toString(LATENTTALENT), 100, 160, 0x463a4f);
		super.drawScreen(mouseX, mouseY, partialTicks);
	}

	@Override
	public void initGui() {

		super.initGui();
	}

	@Override
	protected void actionPerformed(GuiButton button) throws IOException {
		super.actionPerformed(button);
	}

	@Override
	public boolean doesGuiPauseGame() {
		return true;
	}
}
