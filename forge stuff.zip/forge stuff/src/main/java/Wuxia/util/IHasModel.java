package Wuxia.util;

public interface IHasModel {
	public void registerModels();
}
